#!/usr/bin/env python3

import cv2
import numpy as np
import os

def check_and_fix_map_files(map_dir):
    """
    Check and fix occ_map.npy and valid_space.npy files to match MAPEX requirements
    """
    occ_npy_path = os.path.join(map_dir, 'occ_map.npy')
    valid_npy_path = os.path.join(map_dir, 'valid_space.npy')
    
    print(f"Processing map directory: {map_dir}")
    
    # Check if files exist
    if not os.path.exists(occ_npy_path):
        print(f"ERROR: {occ_npy_path} does not exist!")
        return False
        
    if not os.path.exists(valid_npy_path):
        print(f"ERROR: {valid_npy_path} does not exist!")
        return False
    
    # Load and check occ_map.npy
    occ_map = np.load(occ_npy_path)
    unique_vals = np.unique(occ_map)
    print(f"Current occ_map.npy unique values: {unique_vals}")
    
    # Check if already in correct format
    if np.array_equal(unique_vals, [0, 254]):
        print("✅ occ_map.npy is already in correct format!")
    else:
        print("🔧 Fixing occ_map.npy format...")
        
        # Create backup
        backup_path = occ_npy_path + '.backup'
        np.save(backup_path, occ_map)
        print(f"   Backup saved to: {backup_path}")
        
        # Fix the format based on common Gazebo/ROS conventions
        fixed_occ_map = np.zeros_like(occ_map, dtype=np.uint8)
        
        if len(unique_vals) == 2:
            # Binary map - assume lower value = occupied, higher = free
            min_val, max_val = unique_vals[0], unique_vals[1]
            fixed_occ_map[occ_map == min_val] = 0    # occupied -> 0
            fixed_occ_map[occ_map == max_val] = 254  # free -> 254
            
        elif len(unique_vals) == 3:
            # Typical ROS format: 0=free, 100=unknown, 255=occupied
            # Or: 0=occupied, 128=unknown, 255=free
            sorted_vals = np.sort(unique_vals)
            
            if 255 in unique_vals and 0 in unique_vals:
                # Common ROS format
                fixed_occ_map[occ_map == 255] = 0    # was occupied/free -> occupied
                fixed_occ_map[occ_map == 0] = 254    # was free/occupied -> free
                # Handle middle value (unknown) - treat as occupied for safety
                middle_val = sorted_vals[1]
                fixed_occ_map[occ_map == middle_val] = 0
            else:
                # Default: lowest=occupied, highest=free
                fixed_occ_map[occ_map == sorted_vals[0]] = 0    # occupied
                fixed_occ_map[occ_map == sorted_vals[-1]] = 254  # free
                # Middle values -> occupied (safer for robot navigation)
                for val in sorted_vals[1:-1]:
                    fixed_occ_map[occ_map == val] = 0
        else:
            # Multiple values - threshold approach
            # Values closer to 0 = occupied, closer to max = free
            threshold = np.mean(unique_vals)
            fixed_occ_map[occ_map <= threshold] = 0    # occupied
            fixed_occ_map[occ_map > threshold] = 254   # free
        
        # Save fixed map
        np.save(occ_npy_path, fixed_occ_map)
        print(f"   ✅ Fixed occ_map.npy: {unique_vals} -> [0, 254]")
    
    # Check and fix valid_space.npy
    valid_space = np.load(valid_npy_path)
    valid_unique = np.unique(valid_space)
    print(f"valid_space.npy unique values: {valid_unique}")
    
    # Valid space should have 0 (not navigable) and >0 (navigable)
    if len(valid_unique) == 2 and valid_unique[0] == 0:
        print("✅ valid_space.npy looks correct!")
    else:
        print("🔧 Fixing valid_space.npy format...")
        backup_path = valid_npy_path + '.backup'
        np.save(backup_path, valid_space)
        
        # Fix valid space - binary format
        fixed_valid_space = np.zeros_like(valid_space, dtype=np.uint8)
        
        # Assume any non-zero value means navigable
        if len(valid_unique) > 1:
            # Use the occ_map to determine valid space
            occ_map_fixed = np.load(occ_npy_path)  # Load the fixed version
            fixed_valid_space[occ_map_fixed == 254] = 255  # Free space = navigable
            fixed_valid_space[occ_map_fixed == 0] = 0      # Occupied = not navigable
        else:
            # If all same value, create valid space from occ_map
            occ_map_fixed = np.load(occ_npy_path)
            fixed_valid_space[occ_map_fixed == 254] = 255
            fixed_valid_space[occ_map_fixed == 0] = 0
        
        np.save(valid_npy_path, fixed_valid_space)
        print(f"   ✅ Fixed valid_space.npy")
    
    return True

def convert_pgm_to_mapex_format(pgm_path, map_id, kth_maps_dir):
    """
    Convert a PGM file to MAPEX format
    """
    print(f"\n🔄 Converting {pgm_path} to MAPEX format...")
    
    # Create map directory
    map_dir = os.path.join(kth_maps_dir, map_id)
    os.makedirs(map_dir, exist_ok=True)
    
    # Load PGM
    if not os.path.exists(pgm_path):
        print(f"ERROR: {pgm_path} does not exist!")
        return False
        
    pgm_img = cv2.imread(pgm_path, cv2.IMREAD_GRAYSCALE)
    if pgm_img is None:
        print(f"ERROR: Could not load {pgm_path}")
        return False
    
    print(f"Original PGM values: {np.unique(pgm_img)}")
    
    # Convert to MAPEX NPY format: 0=occupied, 254=free
    occ_npy = np.zeros_like(pgm_img, dtype=np.uint8)
    
    # Standard occupancy grid: 0=occupied (black), 255=free (white)
    occ_npy[pgm_img == 0] = 0    # black pixels -> occupied
    occ_npy[pgm_img > 0] = 254   # non-black pixels -> free
    
    # Create valid space (navigable areas)
    valid_space = np.zeros_like(pgm_img, dtype=np.uint8)
    valid_space[pgm_img > 0] = 255  # free space = navigable
    
    # Save files
    np.save(os.path.join(map_dir, 'occ_map.npy'), occ_npy)
    np.save(os.path.join(map_dir, 'valid_space.npy'), valid_space)
    
    # Also copy/convert PGM to PNG for visualization
    cv2.imwrite(os.path.join(map_dir, 'map.png'), pgm_img)
    
    print(f"✅ Created MAPEX format files in: {map_dir}")
    print(f"   - occ_map.npy: {np.unique(occ_npy)}")
    print(f"   - valid_space.npy: {np.unique(valid_space)}")
    
    return True

def main():
    print("MAPEX Map Format Fixer")
    print("=" * 40)
    
    # Configuration
    kth_maps_dir = "/home/nivand/MapEx/kth_test_maps"  # Update this path
    
    # Option 1: Fix existing NPY files
    print("\n📁 Checking existing map directories...")
    map_dirs = ['gazebo_map1', 'gazebo_map2', 'gazebo_map3', 'gazebo_map4', 'gazebo_map5']
    
    for map_id in map_dirs:
        map_dir = os.path.join(kth_maps_dir, map_id)
        if os.path.exists(map_dir):
            success = check_and_fix_map_files(map_dir)
            if success:
                print(f"✅ {map_id} processed successfully\n")
            else:
                print(f"❌ Failed to process {map_id}\n")
        else:
            print(f"⚠️  Directory {map_dir} does not exist")
            
            # Option 2: Convert from PGM files (if you have them)
            pgm_path = f"/path/to/your/{map_id}.pgm"  # Update these paths
            if os.path.exists(pgm_path):
                convert_pgm_to_mapex_format(pgm_path, map_id, kth_maps_dir)
            else:
                print(f"   No PGM file found at {pgm_path}")
                print(f"   Please create {map_dir} manually with occ_map.npy and valid_space.npy")
    
    print("\n🎯 Final verification...")
    for map_id in map_dirs:
        map_dir = os.path.join(kth_maps_dir, map_id)
        occ_path = os.path.join(map_dir, 'occ_map.npy')
        if os.path.exists(occ_path):
            occ_map = np.load(occ_path)
            unique_vals = np.unique(occ_map)
            if np.array_equal(unique_vals, [0, 254]):
                print(f"✅ {map_id}: occ_map.npy format correct")
            else:
                print(f"❌ {map_id}: occ_map.npy still has wrong format: {unique_vals}")

if __name__ == "__main__":
    main()