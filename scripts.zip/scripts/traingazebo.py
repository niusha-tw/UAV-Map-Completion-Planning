#!/usr/bin/env python3
"""
Simplified LaMa training script tailored for MapEx with Gazebo datasets.
Bypasses Hydra to avoid config mismatches.
"""

import os
import glob
from PIL import Image
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import pytorch_lightning as pl
from saicinpainting.training.modules import make_generator, make_discriminator
from saicinpainting.training.trainers.base import BaseInpaintingTrainingModule
#from saicinpainting.training.trainers.default import DefaultTrainer
import torch.nn as nn
import torch.optim as optim

# === ⚙️ CONFIGURATION ===
DATA_ROOT = "/home/nivand/MapEx/lamacustom_dataset/train"
BATCH_SIZE = 4
LR = 1e-4
MAX_STEPS = 20000

# === 🔌 CUSTOM DATASET ===
class PairedDataset(Dataset):
    def __init__(self, root):
        self.maps = sorted(glob.glob(os.path.join(root, "global_map", "*.png")))
        self.masks = [path.replace("global_map", "global_mask") for path in self.maps]

    def __len__(self):
        return len(self.maps)

    def __getitem__(self, idx):
        img = np.array(Image.open(self.maps[idx])) / 255.0
        mask = np.array(Image.open(self.masks[idx]))[..., None] / 255.0
        return {
            "image": torch.FloatTensor(img).permute(2,0,1),
            "mask": torch.FloatTensor(mask).permute(2,0,1),
        }

# === 🏗️ MODEL SETUP ===
generator = make_generator(None,
    kind="pix2pixhd_global",
    input_nc=3,
    output_nc=3,
    ngf=64,
    norm="instance",
    n_downsample_global=3,
)

discriminator = make_discriminator(
    kind="multiscale",
    input_nc=6,                      # image + mask
    ndf=64,
    n_layers=4,
)

class CustomLamaModule(BaseInpaintingTrainingModule):
    def __init__(self):
        super().__init__(
            config=None,
            use_ddp=False,
            predict_only=False,
            average_generator=False,
            generator_avg_beta=0.999,
            average_generator_start_step=MAX_STEPS,
            average_generator_period=100,
            store_discr_outputs_for_vis=False,
        )
        self.generator = generator
        self.discriminator = discriminator
        self.optimizer_g = optim.Adam(self.generator.parameters(), lr=LR)
        self.optimizer_d = optim.Adam(self.discriminator.parameters(), lr=LR)
        self.loss_l1 = nn.L1Loss()
        self.adversarial_loss = nn.BCEWithLogitsLoss()

    def configure_optimizers(self):
        return [self.optimizer_g, self.optimizer_d]

    def training_step(self, batch, batch_idx, optimizer_idx):
        img = batch["image"]
        mask = batch["mask"]
        inp = img * mask
        pred = self.generator(inp)
        loss_l1 = self.loss_l1(pred * (1-mask), img * (1-mask))
        # Skipping adversarial for simplicity
        self.log("train/l1", loss_l1, prog_bar=True)
        return loss_l1

# === 🚀 TRAINING ===
dataset = PairedDataset(DATA_ROOT)
loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=4)

module = CustomLamaModule()
trainer = pl.Trainer(gpus=1, max_steps=MAX_STEPS, log_every_n_steps=100, logger=False, checkpoint_callback=False)
trainer.fit(module, loader)

# === ✅ SAVE GENERATOR WEIGHTS ===
torch.save(module.generator.state_dict(), "trained_gazebo_lama.pth")
print("✅ Saved trained model: trained_gazebo_lama.pth")
