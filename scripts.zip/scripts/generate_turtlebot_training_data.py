#!/usr/bin/env python3
"""
FIXED: Generate Lama training dataset from TurtleBot Gazebo simulation maps
Configured specifically for TurtleBot 2D LiDAR (3.5m range, 359 rays)
Place this file in: MapEx/scripts/generate_turtlebot_training_data_fixed.py
"""

import os
import cv2
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
from skimage.measure import block_reduce
import argparse
import sys

# Fix imports - avoid circular import
# We'll copy the necessary functions locally to avoid the circular import issue

def convert_012_labels_to_maskutils_labels(occ_map):
    """Converts occupancy map that is of 012 label (0: unknown, 1: occupied, 2: free) 
    to maskutils labels (0: free, 0.5: unknown, 1: occupied)"""
    occ_map_copy = np.zeros_like(occ_map).astype(np.float32)
    occ_map_copy[occ_map == 2] = 0      # free
    occ_map_copy[occ_map == 1] = 1      # occupied
    occ_map_copy[occ_map == 0] = 0.5    # unknown
    return occ_map_copy

def create_training_folders(output_base_path):
    """Create the required folder structure for Lama training"""
    folders = [
        'train/global_map',
        'train/global_mask', 
        'test/global_map',
        'test/global_mask'
    ]
    
    for folder in folders:
        full_path = os.path.join(output_base_path, folder)
        os.makedirs(full_path, exist_ok=True)
        print(f"Created: {full_path}")
    
    return output_base_path

def convert_pgm_to_training_format(pgm_path):
    """
    Convert PGM simulation map to MapEx training format
    Optimized for TurtleBot indoor navigation scenarios
    """
    print(f"Processing TurtleBot map: {pgm_path}")
    
    # Load PGM file
    pgm_img = cv2.imread(pgm_path, cv2.IMREAD_GRAYSCALE)
    if pgm_img is None:
        raise ValueError(f"Could not load image: {pgm_path}")
    
    print(f"Original map shape: {pgm_img.shape}")
    print(f"Pixel value range: {pgm_img.min()} - {pgm_img.max()}")
    
    # Convert PGM to occupancy map (0: unknown, 1: occupied, 2: free)
    occ_map = np.zeros_like(pgm_img, dtype=np.uint8)
    
    # ROS/Gazebo PGM convention for TurtleBot:
    # 0-50: occupied (black/dark gray) - walls, obstacles
    # 51-200: unknown (gray) - unexplored areas
    # 201-255: free (white/light gray) - navigable space
    occ_map[pgm_img <= 50] = 1      # occupied
    occ_map[pgm_img >= 200] = 2     # free  
    occ_map[(pgm_img > 50) & (pgm_img < 200)] = 0  # unknown
    
    print(f"TurtleBot map analysis:")
    print(f"  Occupied cells: {np.sum(occ_map==1)} ({np.sum(occ_map==1)/occ_map.size*100:.1f}%)")
    print(f"  Free cells: {np.sum(occ_map==2)} ({np.sum(occ_map==2)/occ_map.size*100:.1f}%)")
    print(f"  Unknown cells: {np.sum(occ_map==0)} ({np.sum(occ_map==0)/occ_map.size*100:.1f}%)")
    
    # Resize if map is too large (for computational efficiency)
    max_size = 2048
    if max(occ_map.shape) > max_size:
        scale_factor = max_size / max(occ_map.shape)
        new_size = (int(occ_map.shape[1] * scale_factor), int(occ_map.shape[0] * scale_factor))
        occ_map = cv2.resize(occ_map, new_size, interpolation=cv2.INTER_NEAREST)
        print(f"Resized map to: {occ_map.shape}")
    
    # Convert to mask_utils format (0: free, 0.5: unknown, 1: occupied)
    mask_utils_map = convert_012_labels_to_maskutils_labels(occ_map)
    
    return mask_utils_map

def simple_lidar_simulation(occupancy_grid, robot_pos, laser_range_pix, num_laser):
    """
    Simple LiDAR simulation without external dependencies
    This replaces the complex get_vis_mask function with a basic version
    """
    
    # Generate angles for LiDAR rays (359 rays from 0 to 2π)
    angles = np.linspace(0, 2*np.pi, num_laser, endpoint=False)
    
    # Initialize visibility mask
    vis_mask = np.ones_like(occupancy_grid) * 0.5  # Start with unknown
    hit_points = []
    
    robot_r, robot_c = int(robot_pos[0]), int(robot_pos[1])
    
    # Simple raycast for each angle
    for angle in angles:
        # Ray direction
        dr = np.cos(angle)
        dc = np.sin(angle)
        
        # Cast ray from robot position
        for distance in range(1, int(laser_range_pix) + 1):
            # Current ray position
            r = int(robot_r + dr * distance)
            c = int(robot_c + dc * distance)
            
            # Check bounds
            if r < 0 or r >= occupancy_grid.shape[0] or c < 0 or c >= occupancy_grid.shape[1]:
                break
                
            # Mark as free space (visible)
            vis_mask[r, c] = 0.0  # free
            
            # Check if hit occupied space
            if occupancy_grid[r, c] == 1.0:  # occupied
                hit_points.append([r, c])
                vis_mask[r, c] = 1.0  # mark hit point as occupied
                break
    
    # Get visible indices (free space)
    vis_ind = np.argwhere(vis_mask == 0.0)
    actual_hit_points = np.array(hit_points) if hit_points else np.empty((0, 2), dtype=int)
    
    return vis_ind, vis_mask, actual_hit_points

def generate_random_trajectory(occupancy_grid, num_steps, step_size_pix):
    """
    Generate a random valid trajectory in the occupancy grid
    """
    # Find free space for starting position
    free_cells = np.argwhere(occupancy_grid < 0.6)  # free or unknown
    if len(free_cells) == 0:
        raise ValueError("No free space found in map")
    
    # Random start position
    start_idx = np.random.randint(len(free_cells))
    current_pos = free_cells[start_idx].astype(float)
    
    trajectory = [current_pos.copy()]
    
    for _ in range(num_steps - 1):
        # Random direction
        angle = np.random.uniform(0, 2*np.pi)
        
        # Calculate next position
        next_pos = current_pos + step_size_pix * np.array([np.cos(angle), np.sin(angle)])
        
        # Check bounds and occupancy
        r, c = int(next_pos[0]), int(next_pos[1])
        if (0 <= r < occupancy_grid.shape[0] and 
            0 <= c < occupancy_grid.shape[1] and 
            occupancy_grid[r, c] < 0.6):  # free space
            current_pos = next_pos
            trajectory.append(current_pos.copy())
        else:
            # If invalid move, try a different direction or stay in place
            trajectory.append(current_pos.copy())
    
    return np.array(trajectory)

def generate_training_pairs_from_map(map_data, map_name, output_path, map_configs):
    """
    Generate training pairs using simplified TurtleBot 2D LiDAR simulation
    """
    
    print(f"\nGenerating TurtleBot training data for map: {map_name}")
    print(f"TurtleBot LiDAR Config (3.5m range, 359 rays):")
    print(f"  Range: {map_configs['laser_range_m']}m")
    print(f"  Rays: {map_configs['num_laser']}")
    print(f"  Resolution: {map_configs['pixel_per_meter']} pixels/meter")
    
    trajectories_per_map = map_configs['trajectories_per_map']
    train_test_split = map_configs.get('train_test_split', 0.9)
    
    # Convert laser range to pixels
    laser_range_pix = int(map_configs['laser_range_m'] * map_configs['pixel_per_meter'])
    step_size_pix = int(map_configs['max_step_size_m'] * map_configs['pixel_per_meter'])
    
    total_pairs_generated = 0
    train_pairs = 0
    test_pairs = 0
    
    for traj_i in tqdm(range(trajectories_per_map), desc=f"TurtleBot trajectories for {map_name}"):
        try:
            # Generate random trajectory
            trajectory = generate_random_trajectory(
                map_data, 
                map_configs['num_trajectory_steps'], 
                step_size_pix
            )
            
            # Sample poses along trajectory for LiDAR scanning
            scan_interval_pix = int(map_configs['collect_interval_m'] * map_configs['pixel_per_meter'])
            scan_poses = trajectory[::max(1, scan_interval_pix // step_size_pix)]
            
            # Convert complete map to RGB
            full_map_rgb = np.stack([map_data, map_data, map_data], axis=2)
            full_map_rgb = (full_map_rgb * 255).astype(np.uint8)
            
            # Generate LiDAR observations at each scan pose
            for scan_idx, robot_pose in enumerate(scan_poses):
                try:
                    # Simulate TurtleBot LiDAR scan
                    vis_ind, lidar_mask, hit_points = simple_lidar_simulation(
                        map_data, robot_pose, laser_range_pix, map_configs['num_laser']
                    )
                    
                    # Convert LiDAR observation to RGB
                    lidar_rgb = np.stack([lidar_mask, lidar_mask, lidar_mask], axis=2)
                    lidar_rgb = (lidar_rgb * 255).astype(np.uint8)
                    
                    # Train/test split
                    is_train = np.random.rand() < train_test_split
                    split = 'train' if is_train else 'test'
                    
                    # Unique filename
                    filename = f"turtlebot_{map_name}_{traj_i:06d}_{scan_idx:03d}.png"
                    
                    # Save training pair
                    map_save_path = os.path.join(output_path, split, 'global_map', filename)
                    mask_save_path = os.path.join(output_path, split, 'global_mask', filename)
                    
                    cv2.imwrite(map_save_path, full_map_rgb)
                    cv2.imwrite(mask_save_path, lidar_rgb)
                    
                    total_pairs_generated += 1
                    if is_train:
                        train_pairs += 1
                    else:
                        test_pairs += 1
                        
                except Exception as e:
                    print(f"Error in scan {scan_idx}: {e}")
                    continue
                    
        except Exception as e:
            print(f"Error in trajectory {traj_i}: {e}")
            continue
    
    print(f"TurtleBot map {map_name} completed:")
    print(f"  Total pairs: {total_pairs_generated}")
    print(f"  Train pairs: {train_pairs}")
    print(f"  Test pairs: {test_pairs}")
    
    return total_pairs_generated

def main():
    # Fixed paths for TurtleBot setup
    input_dir = "/home/nivand/MapEx/gazebomaps"
    output_dir = "/home/nivand/MapEx/training_datasets/turtlebot_simulation_dataset"
    
    parser = argparse.ArgumentParser(description='Generate Lama training data for TurtleBot (FIXED VERSION)')
    parser.add_argument('--trajectories_per_map', type=int, default=150, help='Number of trajectories per map')
    parser.add_argument('--viz', action='store_true', help='Show TurtleBot LiDAR simulation visualization')
    
    args = parser.parse_args()
    
    # YOUR ACTUAL TurtleBot LiDAR Configuration
    turtlebot_lidar_configs = {
        # YOUR EXACT LiDAR Specifications (from laser scan data)
        'laser_range_m': 3.5,             # YOUR actual max range: 3.5m
        'num_laser': 359,                 # YOUR actual ray count: 359 rays
        'pixel_per_meter': 50,            # Very high resolution for short range (2cm/pixel)
        
        # TurtleBot Robot Parameters (adjusted for short-range sensor)
        'max_step_size_m': 1.0,           # Smaller steps for 3.5m range
        'num_trajectory_steps': 60,       # Steps per trajectory
        'collect_interval_m': 1.5,        # LiDAR scan every 1.5 meters
        
        # Training Data Generation
        'trajectories_per_map': args.trajectories_per_map,
        'train_test_split': 0.9,          # 90% train, 10% test
        'show_viz': args.viz,             # Show TurtleBot LiDAR visualizations
    }
    
    print("=== TurtleBot Lama Training Data Generation (FIXED) ===")
    print(f"Input directory: {input_dir}")
    print(f"Output directory: {output_dir}")
    print(f"Trajectories per map: {args.trajectories_per_map}")
    print(f"YOUR TurtleBot LiDAR Configuration:")
    print(f"  Range: {turtlebot_lidar_configs['laser_range_m']}m (SHORT RANGE)")
    print(f"  Rays: {turtlebot_lidar_configs['num_laser']} (~1.003° resolution)")
    print(f"  Map Resolution: {turtlebot_lidar_configs['pixel_per_meter']} pixels/meter (2cm/pixel)")
    print(f"  Min Range: 0.12m, Max Range: 3.5m")
    
    # Create output folder structure
    output_path = create_training_folders(output_dir)
    
    # Find all PGM files in gazebomaps directory
    pgm_files = [f for f in os.listdir(input_dir) if f.endswith(('.pgm', '.PGM'))]
    
    if not pgm_files:
        print("No .pgm files found in gazebomaps directory!")
        return
    
    print(f"\nFound {len(pgm_files)} TurtleBot simulation maps: {pgm_files}")
    
    total_training_pairs = 0
    
    # Process each TurtleBot simulation map
    for pgm_file in pgm_files:
        pgm_path = os.path.join(input_dir, pgm_file)
        map_name = os.path.splitext(pgm_file)[0]  # Remove .pgm extension
        
        try:
            # Convert PGM to training format
            processed_map = convert_pgm_to_training_format(pgm_path)
            
            # Generate training pairs with simplified TurtleBot LiDAR simulation
            pairs_generated = generate_training_pairs_from_map(
                processed_map, map_name, output_path, turtlebot_lidar_configs
            )
            
            total_training_pairs += pairs_generated
            
        except Exception as e:
            print(f"Error processing TurtleBot map {pgm_file}: {e}")
            continue
    
    print(f"\n=== TurtleBot Training Data Generation Complete ===")
    print(f"Total training pairs generated: {total_training_pairs}")
    print(f"Training data saved to: {output_path}")
    print(f"Expected training time: 10-18 hours on modern GPU")
    print(f"\nNext steps:")
    print(f"1. Train model: cd MapEx/lama && python bin/train.py -cn training/turtlebot_simulation")
    print(f"2. Test with TurtleBot: python explore.py -cn turtlebot_short_range")

if __name__ == "__main__":
    main()