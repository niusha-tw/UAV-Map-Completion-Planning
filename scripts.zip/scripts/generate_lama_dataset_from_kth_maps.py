#!/usr/bin/env python3
"""
Generate LaMa-compatible training dataset from MapEx-formatted Gazebo maps
"""

import os
import cv2
import numpy as np
import math
import random
from tqdm import tqdm

# === CONFIGURATION ===
# CHANGE THESE TO MATCH YOUR LOCAL PATHS
KTH_DIR = "/home/nivand/MapEx/kth_test_maps"
OUT_DIR = "/home/nivand/MapEx/lama_custom_dataset"

PIXELS_PER_METER = 50              # 0.02 m/pixel
MAP_RES = 1.0 / PIXELS_PER_METER   # meters/pixel
LIDAR_RANGE = 3.5                  # meters
NUM_LASER = 359                    # rays
NUM_SAMPLES = 5                    # how many LiDAR samples per map

# === CREATE OUTPUT FOLDERS ===
PARTIAL_DIR = os.path.join(OUT_DIR, "train/image_dir")
MASK_DIR = os.path.join(OUT_DIR, "train/mask_dir")
TARGET_DIR = os.path.join(OUT_DIR, "train/target_dir")

for d in [PARTIAL_DIR, MASK_DIR, TARGET_DIR]:
    os.makedirs(d, exist_ok=True)

# === RAYCASTING FUNCTION ===
def raycast_2d(occ_grid, pose, angles, max_range, res):
    hits = []
    h, w = occ_grid.shape
    ox, oy, theta = pose
    for angle in angles:
        angle_global = theta + angle
        for r in np.linspace(0, max_range, int(max_range / res)):
            x = int(ox + (r / res) * math.cos(angle_global))
            y = int(oy + (r / res) * math.sin(angle_global))
            if 0 <= x < w and 0 <= y < h:
                hits.append((x, y))
                if occ_grid[y, x] == 1:  # obstacle
                    break
            else:
                break
    return hits

# === MAIN LOOP FOR MAP PROCESSING ===
map_ids = [d for d in os.listdir(KTH_DIR) if d.startswith("gazebo_map")]

for map_id in tqdm(map_ids, desc="Processing gazebo_mapX"):
    occ_path = os.path.join(KTH_DIR, map_id, "occ_map.npy")
    if not os.path.exists(occ_path):
        print(f"Missing: {occ_path}")
        continue

    occ_map = np.load(occ_path)
    h, w = occ_map.shape
    occ_bin = (occ_map == 0).astype(np.uint8)  # 1 = obstacle, 0 = free
    angles = np.linspace(-math.pi, math.pi, NUM_LASER, endpoint=False)

    # Generate ground-truth RGB map
    target_rgb = np.stack([occ_map] * 3, axis=2).astype(np.uint8)
    target_rgb[occ_map == 254] = 255
    target_rgb[occ_map == 0] = 0
    target_rgb[(occ_map != 0) & (occ_map != 254)] = 127  # unknowns as gray

    # Get candidate free space for poses
    free_points = np.argwhere(occ_map == 254)
    if len(free_points) == 0:
        print(f"No free space found in {map_id}. Skipping.")
        continue

    for i in range(NUM_SAMPLES):
        y, x = random.choice(free_points)
        theta = random.uniform(-math.pi, math.pi)
        pose = [x, y, theta]

        obs = raycast_2d(occ_bin, pose, angles, LIDAR_RANGE, MAP_RES)

        # === Generate mask ===
        mask = np.zeros_like(occ_map, dtype=np.uint8)
        for ox, oy in obs:
            if 0 <= oy < h and 0 <= ox < w:
                mask[oy, ox] = 255  # visible

        # === Generate partial map ===
        partial = target_rgb.copy()
        for c in range(3):
            channel = partial[:, :, c]
            channel[mask == 0] = 127  # unknowns = gray
            partial[:, :, c] = channel

        # === Save ===
        fname = f"{map_id}_obs_{i}.png"
        cv2.imwrite(os.path.join(PARTIAL_DIR, fname), partial)
        cv2.imwrite(os.path.join(MASK_DIR, fname), mask)
        cv2.imwrite(os.path.join(TARGET_DIR, fname), target_rgb)

print("✅ LaMa training dataset generation complete.")
print(f"Saved in: {OUT_DIR}/train/")
