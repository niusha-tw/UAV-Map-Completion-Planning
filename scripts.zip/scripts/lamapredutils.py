# LAMA-based TurtleBot Gazebo Integration for Predictive Mapping and Exploration

import os
import cv2
import numpy as np
import torch
from omegaconf import OmegaConf
import yaml
from torch.utils.data._utils.collate import default_collate
import os
import pickle
import sys
sys.path.append('../lama')
from saicinpainting.training.trainers import load_checkpoint
from saicinpainting.training.data.datasets import get_transforms
from saicinpainting.evaluation.utils import move_to_device

# ROS and visualization
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

import rospy
from nav_msgs.msg import OccupancyGrid, Odometry
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from collections import deque

# --- LAMA Utils ---
def get_lama_transform(transform_variant, out_size):
    map_transform = get_transforms(transform_variant, out_size)
    return map_transform

def convert_obsimg_to_model_input(obs_img, map_transform, device):
    transformed = map_transform(image=obs_img, obs_img=obs_img)
    obs_img = np.transpose(transformed['obs_img'], (2, 0, 1))
    mask = ((obs_img[0] > 0.49) & (obs_img[0] < 0.51)).astype(np.float32)[None, ...]
    input_batch = default_collate([{'image': obs_img, 'mask': mask}])
    input_batch = move_to_device(input_batch, device)
    return input_batch, mask

def load_lama_model(model_path, checkpoint_name='best.ckpt', device='cuda'):
    train_config_path = os.path.join(model_path, 'config.yaml')
    with open(train_config_path, 'r') as f:
        train_config = OmegaConf.create(yaml.safe_load(f))
    checkpoint_path = os.path.join(model_path, 'models', checkpoint_name)
    train_config.training_model.predict_only = True
    train_config.visualizer.kind = 'noop'
    model = load_checkpoint(train_config, checkpoint_path, strict=False, map_location=device).to(device)
    model.freeze()
    return model

def visualize_prediction(batch_pred, mask):
    cur_gt = batch_pred['image'][0].permute(1, 2, 0).cpu().numpy()
    cur_res = np.clip(batch_pred['inpainted'][0].permute(1, 2, 0).detach().cpu().numpy() * 255, 0, 255).astype('uint8')
    cur_res = cv2.cvtColor(cur_res, cv2.COLOR_RGB2BGR)
    cur_gt = np.clip(cur_gt * 255, 0, 255).astype('uint8')
    cur_gt = cv2.cvtColor(cur_gt, cv2.COLOR_RGB2BGR)
    gt_masked = cur_gt.copy()
    gt_masked[mask[0] > 0] = 122
    disp_output = np.vstack([cur_gt, gt_masked, cur_res])
    cv2.imwrite('lama_pred.png', disp_output)
    return cur_res

# --- Main TurtleBot LAMA Node ---


class TurtleBotLAMAIntegration:
    def __init__(self):
        rospy.init_node('turtlebot_lama_explorer')
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.lama_model_path = '/home/nivand/MapEx/pretrained_models/weights/big_lama'
        self.lama_model = load_lama_model(self.lama_model_path, device=self.device)
        self.lama_transform = get_lama_transform('default_map_eval', (512, 512))

        self.map_size = (1000, 1000)
        self.resolution = 0.05
        self.origin = np.array([500, 500])
        self.obs_map = np.ones(self.map_size) * 0.5
        self.robot_pose = self.origin.copy()
        self.pose_history = deque(maxlen=1000)

        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)
        self.laser_sub = rospy.Subscriber('/scan', LaserScan, self.laser_callback)
        self.cmd_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.lama_pub = rospy.Publisher('/lama_map_predicted', OccupancyGrid, queue_size=1)

        self.laser_range_m = 10.0
        self.num_laser = 360
        self.exploration_step = 0

        plt.ion()
        self.fig, self.axes = plt.subplots(1, 3, figsize=(15, 5))
        self.last_pred_img = None
        self.last_frontiers = None
        self.last_exploration_step = None

        self.visited_frontiers = []
        self.visited_frontiers_path = '/tmp/visited_frontiers.pkl'
        if os.path.exists(self.visited_frontiers_path):
            with open(self.visited_frontiers_path, 'rb') as f:
                self.visited_frontiers = pickle.load(f)



    def odom_callback(self, msg):
        x = msg.pose.pose.position.x / self.resolution + self.origin[0]
        y = msg.pose.pose.position.y / self.resolution + self.origin[1]
        self.robot_pose = np.array([int(y), int(x)])
        self.pose_history.append(self.robot_pose.copy())

    def laser_callback(self, msg):
        if len(msg.ranges) == 0:
            return
        self.update_occupancy_grid(msg)
        if self.exploration_step % 10 == 0:
            self.run_lama_prediction()
        self.exploration_step += 1

    def update_occupancy_grid(self, laser_msg):
        ranges = np.array(laser_msg.ranges)
        angles = np.linspace(laser_msg.angle_min, laser_msg.angle_max, len(ranges))
        valid = (ranges > laser_msg.range_min) & (ranges < laser_msg.range_max)

        robot_row, robot_col = self.robot_pose

        for r, a in zip(ranges[valid], angles[valid]):
            end_x = robot_col + (r / self.resolution) * np.cos(a)
            end_y = robot_row + (r / self.resolution) * np.sin(a)
            end_row, end_col = int(end_y), int(end_x)
            if 0 <= end_row < self.map_size[0] and 0 <= end_col < self.map_size[1]:
                points = self.bresenham_line(robot_row, robot_col, end_row, end_col)
                for y, x in points[:-1]:
                    self.obs_map[y, x] = 0  # free
                self.obs_map[end_row, end_col] = 1  # occupied

    def bresenham_line(self, x0, y0, x1, y1):
        points = []
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        x, y = x0, y0
        sx = -1 if x0 > x1 else 1
        sy = -1 if y0 > y1 else 1
        if dx > dy:
            err = dx / 2.0
            while x != x1:
                points.append((x, y))
                err -= dy
                if err < 0:
                    y += sy
                    err += dx
                x += sx
        else:
            err = dy / 2.0
            while y != y1:
                points.append((x, y))
                err -= dx
                if err < 0:
                    x += sx
                    err += dy
                y += sy
        points.append((x1, y1))
        return points


    def run_lama_prediction(self):
        try:
            obs_img = self.prepare_lama_input()
            pred_img = self.get_lama_prediction(obs_img)
            self.process_prediction(pred_img)
        except Exception as e:
            rospy.logerr(f"LAMA prediction failed: {e}")

    def prepare_lama_input(self):
        h, w = self.obs_map.shape
        pad_h = (16 - h % 16) % 16
        pad_w = (16 - w % 16) % 16
        padded_map = np.pad(self.obs_map,
                            ((pad_h//2, pad_h-pad_h//2), (pad_w//2, pad_w-pad_w//2)),
                            mode='constant', constant_values=0.5)
        obs_img = np.zeros((padded_map.shape[0], padded_map.shape[1], 3), dtype=np.uint8)
        obs_img[padded_map == 0] = [255, 255, 255]
        obs_img[padded_map == 0.5] = [128, 128, 128]
        obs_img[padded_map == 1] = [0, 0, 0]
        return obs_img

    def get_lama_prediction(self, obs_img):
        input_batch, mask = convert_obsimg_to_model_input(obs_img, self.lama_transform, self.device)
        with torch.no_grad():
            prediction = self.lama_model(input_batch)
        pred_viz = visualize_prediction(prediction, mask)
        return pred_viz

    def processprediction(self, pred_img):
        pred_map = np.zeros((pred_img.shape[0], pred_img.shape[1]))
        gray_pred = cv2.cvtColor(pred_img, cv2.COLOR_BGR2GRAY)
        pred_map[gray_pred < 100] = 1
        pred_map[gray_pred > 200] = 0
        pred_map[(gray_pred >= 100) & (gray_pred <= 200)] = 0.5
        frontiers = self.detect_frontiers(pred_map)

        if len(frontiers) == 0:
            rospy.logwarn("No frontiers found. Rotating in place to recover...")
            self.rotate_in_place()
        else:
            frontiers = [f for f in frontiers if not any(np.allclose(f, v, atol=10) for v in self.visited_frontiers)]
            if len(frontiers) == 0:
                rospy.logwarn("All frontiers previously visited. Rotating in place...")
                self.rotate_in_place()
                return
            distances = [np.linalg.norm(f - self.robot_pose) for f in frontiers]
            nearest_frontier = frontiers[np.argmin(distances)]
            self.visited_frontiers.append(nearest_frontier)
            with open(self.visited_frontiers_path, 'wb') as f:
                pickle.dump(self.visited_frontiers, f)
            self.navigate_to_goal(nearest_frontier)

        self.last_pred_img = pred_img
        self.last_frontiers = frontiers
        self.last_exploration_step = self.exploration_step
        self.publish_lama_map(pred_map)


    def process_prediction(self, pred_img):
        pred_map = np.zeros((pred_img.shape[0], pred_img.shape[1]))
        gray_pred = cv2.cvtColor(pred_img, cv2.COLOR_BGR2GRAY)
        pred_map[gray_pred < 100] = 1
        pred_map[gray_pred > 200] = 0
        pred_map[(gray_pred >= 100) & (gray_pred <= 200)] = 0.5
        frontiers = self.detect_frontiers(pred_map)

        rospy.loginfo("Detected %d frontiers (teleop-only mode, not navigating)", len(frontiers))

        self.last_pred_img = pred_img
        self.last_frontiers = frontiers
        self.last_exploration_step = self.exploration_step
        self.publish_lama_map(pred_map)


    def rotate_in_place(self):
        twist = Twist()
        twist.angular.z = 0.5
        self.cmd_pub.publish(twist)
        rospy.sleep(2.0)
        twist.angular.z = 0.0
        self.cmd_pub.publish(twist)




    def navigate_to_goal(self, goal):
        if goal is None:
            return
        direction = goal - self.robot_pose
        distance = np.linalg.norm(direction)
        if distance > 5:
            direction = direction / distance
            cmd = Twist()
            cmd.linear.x = min(0.2, distance * 0.1)
            cmd.angular.z = np.arctan2(direction[1], direction[0]) * 0.5
            self.cmd_pub.publish(cmd)
        else:
            self.cmd_pub.publish(Twist())

    def detect_frontiers(self, pred_map):
        frontiers = []
        for i in range(1, pred_map.shape[0]-1):
            for j in range(1, pred_map.shape[1]-1):
                if pred_map[i, j] == 0:
                    neighbors = pred_map[i-1:i+2, j-1:j+2]
                    if 0.5 in neighbors:
                        frontiers.append(np.array([i, j]))
        return frontiers

    def publish_lama_map(self, pred_map):
        msg = OccupancyGrid()
        msg.header.stamp = rospy.Time.now()
        msg.header.frame_id = "map"
        msg.info.resolution = self.resolution
        msg.info.width = pred_map.shape[1]
        msg.info.height = pred_map.shape[0]
        msg.info.origin.position.x = -self.origin[0] * self.resolution
        msg.info.origin.position.y = -self.origin[1] * self.resolution
        msg.info.origin.position.z = 0
        msg.info.origin.orientation.w = 1.0
        ros_data = np.full(pred_map.shape, -1, dtype=np.int8)
        ros_data[pred_map == 0] = 0
        ros_data[pred_map == 1] = 100
        msg.data = ros_data.flatten().tolist()
        self.lama_pub.publish(msg)

    def visualize_results(self, pred_img, frontiers, exploration_step):
        self.axes[0].cla()
        self.axes[1].cla()
        self.axes[2].cla()
        self.axes[0].imshow(self.obs_map, cmap='gray')
        self.axes[0].scatter(self.robot_pose[1], self.robot_pose[0], c='red', s=50, marker='*')
        if len(self.pose_history) > 1:
            poses = np.array(list(self.pose_history))
            self.axes[0].plot(poses[:, 1], poses[:, 0], 'r-', alpha=0.5)
        self.axes[0].set_title('Observed Map')
        self.axes[1].imshow(pred_img)
        self.axes[1].set_title('LAMA Prediction')
        self.axes[2].imshow(self.obs_map, cmap='gray')
        if frontiers is not None and len(frontiers) > 0:
            frontiers_array = np.array(frontiers)
            self.axes[2].scatter(frontiers_array[:, 1], frontiers_array[:, 0], c='blue', s=20, marker='o')
        self.axes[2].scatter(self.robot_pose[1], self.robot_pose[0], c='red', s=50, marker='*')
        self.axes[2].set_title('Frontiers')
        plt.tight_layout()
        plt.pause(0.01)
        if exploration_step is not None:
            plt.savefig(f'/home/nivand/MapEx/tmp/lama_exploration_{exploration_step}.png')

    def run(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            if self.last_pred_img is not None and self.last_frontiers is not None:
                self.visualize_results(self.last_pred_img, self.last_frontiers, self.last_exploration_step)
            plt.pause(0.01)
            rate.sleep()


if __name__ == '__main__':
    try:
        explorer = TurtleBotLAMAIntegration()
        explorer.run()
    except rospy.ROSInterruptException:
        pass
