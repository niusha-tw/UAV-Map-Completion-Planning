#!/usr/bin/env python3
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

import rospy
import numpy as np
import cv2
from nav_msgs.msg import OccupancyGrid, Odometry
from sensor_msgs.msg import LaserScan
import torch
from collections import deque
import os

# Import LaMa utilities (assume in PYTHONPATH)
from lama_pred_utils import load_lama_model, get_lama_transform, convert_obsimg_to_model_input, visualize_prediction

class LaMaScanPredictor:
    def __init__(self):
        rospy.init_node('lama_scan_predictor')
        self.device = 'cpu'  # Change to 'cuda' if GPU is available
        self.lama_model_path = '/home/nivand/MapEx/pretrained_models/weights/big_lama'
        self.lama_model = load_lama_model(self.lama_model_path, device=self.device)
        self.lama_transform = get_lama_transform('default_map_eval', (512, 512))

        # Occupancy grid parameters
        self.map_size = (1000, 1000)
        self.resolution = 0.05
        self.origin = np.array([500, 500])  # Center of grid at (0,0)

        self.obs_map = np.ones(self.map_size, dtype=np.float32) * 0.5  # unknown everywhere
        self.robot_pose = np.array([500, 500, 0.0])  # (row, col, theta)
        self.pose_history = deque(maxlen=2000)

        self.laser_range_max = 10.0
        self.exploration_step = 0

        # Subscribers
        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)
        self.scan_sub = rospy.Subscriber('/scan', LaserScan, self.scan_callback)
        self.lama_pub = rospy.Publisher('/lama_map_predicted', OccupancyGrid, queue_size=1)

        # Visualization
        plt.ion()
        self.fig, self.axes = plt.subplots(1, 3, figsize=(15, 5))
        self.save_dir = '/tmp/lama_scan_exploration'
        os.makedirs(self.save_dir, exist_ok=True)

        self.last_pred_img = None
        self.last_exploration_step = None

    def odom_callback(self, msg):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        theta = self.get_yaw_from_quat(msg.pose.pose.orientation)
        row = int(y / self.resolution + self.origin[0])
        col = int(x / self.resolution + self.origin[1])
        self.robot_pose = np.array([row, col, theta])
        self.pose_history.append([row, col])

    def scan_callback(self, msg):
        if self.robot_pose is None:
            return
        self.update_occupancy_grid_from_scan(msg)
        if self.exploration_step % 10 == 0:
            self.run_lama_prediction()
        self.exploration_step += 1

    def update_occupancy_grid_from_scan(self, scan_msg):
        row, col, theta = self.robot_pose
        angles = np.arange(scan_msg.angle_min, scan_msg.angle_max, scan_msg.angle_increment)
        ranges = np.array(scan_msg.ranges)
        
        for i, r in enumerate(ranges):
            if not np.isfinite(r) or r < scan_msg.range_min or r > scan_msg.range_max:
                continue
            angle = angles[i] + theta
            end_x = col + (r / self.resolution) * np.cos(angle)
            end_y = row + (r / self.resolution) * np.sin(angle)
            end_row, end_col = int(end_y), int(end_x)
            if 0 <= end_row < self.map_size[0] and 0 <= end_col < self.map_size[1]:
                for p in self.bresenham_line(row, col, end_row, end_col):
                    px, py = int(p[0]), int(p[1])
                    if (0 <= px < self.map_size[0]) and (0 <= py < self.map_size[1]):
                        if (px == end_row) and (py == end_col):
                            self.obs_map[px, py] = 1   # occupied
                        else:
                            self.obs_map[px, py] = 0   # free


    def bresenham_line(self, x0, y0, x1, y1):
        points = []
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        x, y = x0, y0
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        if dx > dy:
            err = dx / 2.0
            while x != x1:
                points.append((x, y))
                err -= dy
                if err < 0:
                    y += sy
                    err += dx
                x += sx
        else:
            err = dy / 2.0
            while y != y1:
                points.append((x, y))
                err -= dx
                if err < 0:
                    x += sx
                    err += dy
                y += sy
        points.append((x1, y1))
        return points

    def run_lama_prediction(self):
        obs_img = self.prepare_lama_input()
        pred_img = self.get_lama_prediction(obs_img)
        self.visualize_and_publish(obs_img, pred_img)
        self.last_pred_img = pred_img
        self.last_exploration_step = self.exploration_step

    def prepare_lama_input(self):
        # Optionally crop for LaMa speed, or pad to multiple of 16
        obs_map = self.obs_map.copy()
        h, w = obs_map.shape
        pad_h = (16 - h % 16) % 16
        pad_w = (16 - w % 16) % 16
        obs_map = np.pad(obs_map, ((pad_h//2, pad_h - pad_h//2),
                                   (pad_w//2, pad_w - pad_w//2)), constant_values=0.5)
        obs_img = np.zeros((obs_map.shape[0], obs_map.shape[1], 3), dtype=np.uint8)
        obs_img[obs_map == 0] = [255, 255, 255]
        obs_img[obs_map == 0.5] = [128, 128, 128]
        obs_img[obs_map == 1] = [0, 0, 0]
        return obs_img

    def get_lama_prediction(self, obs_img):
        input_batch, mask = convert_obsimg_to_model_input(obs_img, self.lama_transform, self.device)
        with torch.no_grad():
            prediction = self.lama_model(input_batch)
        pred_viz = visualize_prediction(prediction, mask)
        return pred_viz

    def visualize_and_publish(self, obs_img, pred_img):
        ax = self.axes
        ax[0].cla(); ax[1].cla(); ax[2].cla()
        # Observed map + trajectory
        ax[0].imshow(self.obs_map, cmap='gray')
        if len(self.pose_history) > 1:
            poses = np.array(self.pose_history)
            ax[0].plot(poses[:, 1], poses[:, 0], 'r-', alpha=0.6, lw=1.2)
        ax[0].set_title("Accumulated Scan Map + Trajectory")
        # LaMa prediction
        ax[1].imshow(pred_img)
        ax[1].set_title("LaMa Prediction")
        # Difference (optional)
        ax[2].imshow(obs_img)
        ax[2].set_title("Current Observation (Input)")
        plt.tight_layout()
        plt.pause(0.01)
        plt.savefig(os.path.join(self.save_dir, f'lama_pred_{self.exploration_step:04d}.png'))

        # Publish to RViz as OccupancyGrid
        self.publish_lama_map(pred_img)

    def publish_lama_map(self, pred_img):
        msg = OccupancyGrid()
        msg.header.stamp = rospy.Time.now()
        msg.header.frame_id = "map"
        h, w = pred_img.shape[:2]
        msg.info.resolution = self.resolution
        msg.info.width = w
        msg.info.height = h
        msg.info.origin.position.x = -self.origin[0] * self.resolution
        msg.info.origin.position.y = -self.origin[1] * self.resolution
        msg.info.origin.orientation.w = 1.0
        gray_pred = cv2.cvtColor(pred_img, cv2.COLOR_BGR2GRAY)
        ros_data = np.full((h, w), -1, dtype=np.int8)
        ros_data[gray_pred < 100] = 100  # occupied
        ros_data[gray_pred > 200] = 0    # free
        msg.data = ros_data.flatten().tolist()
        self.lama_pub.publish(msg)

    @staticmethod
    def get_yaw_from_quat(q):
        # ROS Quaternion to Euler yaw
        import math
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def run(self):
        rospy.loginfo("LaMa Scan Predictor running!")
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            plt.pause(0.01)
            rate.sleep()

if __name__ == "__main__":
    try:
        node = LaMaScanPredictor()
        node.run()
    except rospy.ROSInterruptException:
        pass
