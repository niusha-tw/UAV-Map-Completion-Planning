#!/usr/bin/env python3
"""
Simple script to convert your 3 PGM maps to Lama-compatible PNG format
This prepares data for Lama's built-in training pipeline
"""

import os
import cv2
import numpy as np

def convert_pgm_to_lama_png(input_dir, output_dir):
    """
    Convert PGM maps to PNG format for Lama's built-in training
    """
    
    # Create output directories
    train_dir = os.path.join(output_dir, 'train')
    test_dir = os.path.join(output_dir, 'test')
    os.makedirs(train_dir, exist_ok=True)
    os.makedirs(test_dir, exist_ok=True)
    
    # Find PGM files
    pgm_files = [f for f in os.listdir(input_dir) if f.endswith(('.pgm', '.PGM'))]
    print(f"Found {len(pgm_files)} PGM files: {pgm_files}")
    
    for i, pgm_file in enumerate(pgm_files):
        pgm_path = os.path.join(input_dir, pgm_file)
        
        # Load PGM
        pgm_img = cv2.imread(pgm_path, cv2.IMREAD_GRAYSCALE)
        print(f"Processing {pgm_file}: shape={pgm_img.shape}, range={pgm_img.min()}-{pgm_img.max()}")
        
        # Convert to standard format
        # PGM: 0=occupied, 255=free
        # Lama expects: 0=black, 255=white
        processed_img = np.zeros_like(pgm_img)
        processed_img[pgm_img <= 50] = 0      # Obstacles → black
        processed_img[pgm_img >= 200] = 255   # Free space → white
        processed_img[(pgm_img > 50) & (pgm_img < 200)] = 128  # Unknown → gray
        
        # Convert to 3-channel RGB
        rgb_img = cv2.cvtColor(processed_img, cv2.COLOR_GRAY2RGB)
        
        # Save to both train and test (Lama will handle augmentation)
        train_path = os.path.join(train_dir, f"{i+1:06d}.png")
        test_path = os.path.join(test_dir, f"{i+1:06d}.png")
        
        cv2.imwrite(train_path, rgb_img)
        cv2.imwrite(test_path, rgb_img)
        
        print(f"Saved: {train_path} and {test_path}")
    
    print(f"\nConversion complete!")
    print(f"Train images: {len(os.listdir(train_dir))}")
    print(f"Test images: {len(os.listdir(test_dir))}")
    print(f"Ready for Lama training with built-in mask generation!")

if __name__ == "__main__":
    input_dir = "/home/nivand/MapEx/gazebomaps"
    output_dir = "/home/nivand/MapEx/training_datasets/gazebo_simple_dataset"
    
    convert_pgm_to_lama_png(input_dir, output_dir)