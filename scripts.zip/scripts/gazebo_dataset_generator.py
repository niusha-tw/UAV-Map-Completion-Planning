#!/usr/bin/env python3
"""
Script 2: Gazebo Dataset Generator
Location: ~/MapEx/gazebo_dataset_generator.py

Purpose: Generate LAMA training dataset from your converted Gazebo maps
Input: Converted maps from Script 1
Output: Training dataset in LAMA format (images + masks)

This generates realistic robot exploration trajectories and creates image/mask pairs
that LAMA can use for training to predict unknown map regions.
"""

import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from tqdm import tqdm
import json
import sys

# Add MapEx scripts to path for mask utilities
sys.path.append('/home/nivand/MapEx/scripts')  # UPDATE THIS PATH
import simple_mask_utils as smu

class GazeboDatasetGenerator:
    def __init__(self, mapex_root):
        self.mapex_root = Path(mapex_root)
        self.maps_dir = self.mapex_root / "kth_test_maps"
        self.dataset_dir = self.mapex_root / "gazebo_lama_dataset"
        
        # TurtleBot/Gazebo-specific configuration
        self.config = {
            # Robot/Sensor parameters (adjust for your TurtleBot)
            'laser_range_m': 8,           # TurtleBot laser range (meters)
            'laser_range_pixels': 160,    # 8m * 20 pixels/m = 160 pixels
            'num_laser_rays': 360,        # 360-degree coverage
            'pixel_per_meter': 20,        # Map resolution
            
            # Data generation parameters
            'trajectories_per_map': 20,   # Number of exploration trajectories per map
            'poses_per_trajectory': 15,   # Observation points along each trajectory
            'min_trajectory_length': 100, # Minimum distance between start/end
            
            # Dataset parameters
            'output_image_size': 512,     # LAMA input size
            'test_split_ratio': 0.2,      # 20% for testing
            'min_unknown_ratio': 0.15,    # Skip samples with too little unknown area
        }
        
        print(f"🏠 MapEx root: {self.mapex_root}")
        print(f"📊 Dataset output: {self.dataset_dir}")
        print(f"🤖 TurtleBot laser range: {self.config['laser_range_m']}m")
        print(f"📡 Laser rays: {self.config['num_laser_rays']}")
    
    def setup_dataset_directories(self):
        """Create dataset directory structure"""
        print(f"\n📁 Setting up dataset directories...")
        
        # LAMA expects this structure:
        # dataset/
        #   ├── train/
        #   │   ├── [image_files].png
        #   │   └── [mask_files].png  
        #   └── test/
        #       ├── [image_files].png
        #       └── [mask_files].png
        
        dirs = {
            'train': self.dataset_dir / 'train',
            'test': self.dataset_dir / 'test',
            'visualizations': self.dataset_dir / 'visualizations'
        }
        
        for dir_path in dirs.values():
            dir_path.mkdir(parents=True, exist_ok=True)
        
        print(f"   ✅ Created: {self.dataset_dir}")
        return dirs
    
    def load_converted_map(self, map_id):
        """Load a converted Gazebo map"""
        print(f"📋 Loading {map_id}...")
        
        map_dir = self.maps_dir / map_id
        occ_path = map_dir / "occ_map.npy"
        valid_path = map_dir / "valid_space.npy"
        
        if not occ_path.exists() or not valid_path.exists():
            print(f"❌ Map files not found for {map_id}")
            return None
        
        # Load maps
        occ_map = np.load(occ_path)
        valid_space = np.load(valid_path)
        
        # Verify format
        occ_unique = np.unique(occ_map)
        if not np.array_equal(occ_unique, [0, 254]):
            print(f"❌ Wrong occ_map format: {occ_unique}, expected [0, 254]")
            return None
        
        # Convert to internal format (0=unknown, 1=occupied, 2=free)
        internal_map = np.zeros_like(occ_map)
        internal_map[occ_map == 0] = 1    # occupied
        internal_map[occ_map == 254] = 2  # free
        
        # Convert valid space to binary
        valid_binary = (valid_space > 0).astype(np.uint8)
        
        print(f"   📏 Map shape: {internal_map.shape}")
        print(f"   🎨 Internal map values: {np.unique(internal_map)}")
        print(f"   🚶 Valid positions: {np.sum(valid_binary)}")
        
        return {
            'occupancy_map': internal_map,
            'valid_space': valid_binary,
            'map_id': map_id
        }
    
    def generate_exploration_trajectory(self, valid_space, occupancy_map):
        """Generate a single exploration trajectory"""
        # Find valid robot positions
        valid_positions = np.where(valid_space > 0)
        if len(valid_positions[0]) < 50:
            return None
        
        # Sample random start and end positions
        start_idx = np.random.randint(len(valid_positions[0]))
        start_pos = (valid_positions[0][start_idx], valid_positions[1][start_idx])
        
        # Find end position with minimum distance requirement
        max_attempts = 50
        for _ in range(max_attempts):
            end_idx = np.random.randint(len(valid_positions[0]))
            end_pos = (valid_positions[0][end_idx], valid_positions[1][end_idx])
            
            distance = np.linalg.norm(np.array(start_pos) - np.array(end_pos))
            if distance >= self.config['min_trajectory_length']:
                break
        else:
            return None  # Could not find suitable end position
        
        # Create trajectory points
        num_poses = self.config['poses_per_trajectory']
        trajectory = []
        
        for i in range(num_poses):
            t = i / (num_poses - 1)
            pose = (
                int(start_pos[0] + t * (end_pos[0] - start_pos[0])),
                int(start_pos[1] + t * (end_pos[1] - start_pos[1]))
            )
            
            # Verify pose is valid
            if (0 <= pose[0] < occupancy_map.shape[0] and 
                0 <= pose[1] < occupancy_map.shape[1] and 
                occupancy_map[pose[0], pose[1]] != 1):  # not occupied
                trajectory.append(pose)
        
        return trajectory if len(trajectory) >= 5 else None
    
    def simulate_turtlebot_observation(self, robot_pos, occupancy_map):
        """Simulate TurtleBot's 2D LiDAR observation"""
        observed_map = np.ones_like(occupancy_map) * 0.5  # Start with unknown (0.5)
        
        # TurtleBot LiDAR simulation
        max_range = self.config['laser_range_pixels']
        num_rays = self.config['num_laser_rays']
        angles = np.linspace(0, 2*np.pi, num_rays)
        
        for angle in angles:
            # Cast ray from robot position
            for r in range(1, max_range):
                x = int(robot_pos[0] + r * np.cos(angle))
                y = int(robot_pos[1] + r * np.sin(angle))
                
                # Check bounds
                if (x < 0 or x >= occupancy_map.shape[0] or 
                    y < 0 or y >= occupancy_map.shape[1]):
                    break
                
                # Mark cell as observed
                observed_map[x, y] = occupancy_map[x, y]
                
                # Stop ray if hit obstacle
                if occupancy_map[x, y] == 1:  # occupied
                    break
        
        return observed_map
    
    def create_lama_training_sample(self, observed_map, map_id, traj_id, pose_id):
        """Convert robot observation to LAMA training format"""
        # Check if there's enough unknown area to make it interesting
        unknown_ratio = np.sum(observed_map == 0.5) / observed_map.size
        if unknown_ratio < self.config['min_unknown_ratio']:
            return None  # Skip boring samples with too little unknown area
        
        # Create RGB image for LAMA input
        image_rgb = np.zeros((*observed_map.shape, 3), dtype=np.uint8)
        image_rgb[observed_map == 0.5] = [128, 128, 128]  # unknown -> gray
        image_rgb[observed_map == 2] = [255, 255, 255]    # free -> white
        image_rgb[observed_map == 1] = [0, 0, 0]          # occupied -> black
        
        # Create binary mask for inpainting (1=unknown regions to fill)
        mask = np.zeros(observed_map.shape, dtype=np.uint8)
        mask[observed_map == 0.5] = 255  # unknown regions
        
        # Resize to LAMA input size (512x512)
        image_512 = cv2.resize(image_rgb, (self.config['output_image_size'], 
                                          self.config['output_image_size']))
        mask_512 = cv2.resize(mask, (self.config['output_image_size'], 
                                    self.config['output_image_size']))
        
        # Ensure mask is binary after resize
        mask_512 = (mask_512 > 127).astype(np.uint8) * 255
        
        return {
            'image': image_512,
            'mask': mask_512,
            'metadata': {
                'map_id': map_id,
                'trajectory_id': traj_id,
                'pose_id': pose_id,
                'unknown_ratio': unknown_ratio
            }
        }
    
    def generate_map_dataset(self, map_data):
        """Generate all training samples for one map"""
        map_id = map_data['map_id']
        occupancy_map = map_data['occupancy_map']
        valid_space = map_data['valid_space']
        
        print(f"🎯 Generating dataset for {map_id}...")
        print(f"   Target: {self.config['trajectories_per_map']} trajectories")
        
        all_samples = []
        successful_trajectories = 0
        
        for traj_id in tqdm(range(self.config['trajectories_per_map'] * 2),  # Try more to get enough good ones
                           desc=f"Trajectories for {map_id}"):
            
            if successful_trajectories >= self.config['trajectories_per_map']:
                break  # We have enough good trajectories
            
            # Generate trajectory
            trajectory = self.generate_exploration_trajectory(valid_space, occupancy_map)
            if trajectory is None:
                continue
            
            # Generate observations along trajectory
            cumulative_observed = np.ones_like(occupancy_map) * 0.5  # Start unknown
            trajectory_samples = []
            
            for pose_id, robot_pos in enumerate(trajectory):
                # Simulate robot observation at this pose
                new_observation = self.simulate_turtlebot_observation(robot_pos, occupancy_map)
                
                # Update cumulative observation
                mask = (new_observation != 0.5)
                cumulative_observed[mask] = new_observation[mask]
                
                # Create LAMA training sample
                sample = self.create_lama_training_sample(
                    cumulative_observed, map_id, successful_trajectories, pose_id
                )
                
                if sample is not None:
                    trajectory_samples.append(sample)
            
            if len(trajectory_samples) >= 5:  # Need at least 5 good samples per trajectory
                all_samples.extend(trajectory_samples)
                successful_trajectories += 1
        
        print(f"   ✅ Generated {len(all_samples)} samples from {successful_trajectories} trajectories")
        return all_samples
    
    def save_dataset_samples(self, all_samples, dirs):
        """Save samples to train/test directories"""
        print(f"\n💾 Saving dataset samples...")
        
        # Shuffle samples
        np.random.shuffle(all_samples)
        
        # Split train/test
        split_idx = int(len(all_samples) * (1 - self.config['test_split_ratio']))
        train_samples = all_samples[:split_idx]
        test_samples = all_samples[split_idx:]
        
        print(f"   📊 Train samples: {len(train_samples)}")
        print(f"   📊 Test samples: {len(test_samples)}")
        
        # Save training samples
        for i, sample in enumerate(tqdm(train_samples, desc="Saving train")):
            base_filename = f"train_{i:06d}"
            
            # Save image and mask with proper naming for LAMA
            image_path = dirs['train'] / f"{base_filename}.png"
            mask_path = dirs['train'] / f"{base_filename}_mask.png"
            
            cv2.imwrite(str(image_path), sample['image'])
            cv2.imwrite(str(mask_path), sample['mask'])
        
        # Save test samples
        for i, sample in enumerate(tqdm(test_samples, desc="Saving test")):
            base_filename = f"test_{i:06d}"
            
            image_path = dirs['test'] / f"{base_filename}.png"
            mask_path = dirs['test'] / f"{base_filename}_mask.png"
            
            cv2.imwrite(str(image_path), sample['image'])
            cv2.imwrite(str(mask_path), sample['mask'])
        
        # Save dataset metadata
        metadata = {
            'config': self.config,
            'dataset_stats': {
                'total_samples': len(all_samples),
                'train_samples': len(train_samples),
                'test_samples': len(test_samples),
                'test_split_ratio': self.config['test_split_ratio']
            }
        }
        
        metadata_path = self.dataset_dir / 'dataset_info.json'
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"   📋 Metadata saved: {metadata_path}")
        
        return len(train_samples), len(test_samples)
    
    def create_sample_visualizations(self, all_samples, dirs, num_samples=5):
        """Create visualizations of sample training pairs"""
        print(f"\n📊 Creating sample visualizations...")
        
        # Select random samples for visualization
        sample_indices = np.random.choice(len(all_samples), 
                                        min(num_samples, len(all_samples)), 
                                        replace=False)
        
        for i, idx in enumerate(sample_indices):
            sample = all_samples[idx]
            
            fig, axes = plt.subplots(1, 3, figsize=(15, 5))
            
            # Input image (with unknown regions)
            axes[0].imshow(sample['image'])
            axes[0].set_title('Input Image\n(Gray = Unknown)')
            axes[0].axis('off')
            
            # Inpainting mask
            axes[1].imshow(sample['mask'], cmap='gray')
            axes[1].set_title('Inpainting Mask\n(White = Fill)')
            axes[1].axis('off')
            
            # Overlay (red = regions to inpaint)
            overlay = sample['image'].copy()
            mask_regions = sample['mask'] > 0
            overlay[mask_regions] = [255, 0, 0]  # Red for unknown regions
            axes[2].imshow(overlay)
            axes[2].set_title('Overlay\n(Red = To Inpaint)')
            axes[2].axis('off')
            
            metadata = sample['metadata']
            plt.suptitle(f"Sample {i+1}: {metadata['map_id']} "
                        f"(Unknown: {metadata['unknown_ratio']:.1%})")
            plt.tight_layout()
            
            viz_path = dirs['visualizations'] / f'sample_{i+1:02d}.png'
            plt.savefig(viz_path, dpi=150, bbox_inches='tight')
            plt.close()
        
        print(f"   📊 Visualizations saved in: {dirs['visualizations']}")
    
    def generate_complete_dataset(self, map_ids):
        """Generate complete dataset from all maps"""
        print(f"🚀 GENERATING COMPLETE DATASET")
        print(f"=" * 50)
        print(f"Maps to process: {map_ids}")
        
        # Setup directories
        dirs = self.setup_dataset_directories()
        
        # Generate samples from all maps
        all_samples = []
        
        for map_id in map_ids:
            # Load map
            map_data = self.load_converted_map(map_id)
            if map_data is None:
                print(f"⚠️  Skipping {map_id} - could not load")
                continue
            
            # Generate samples for this map
            map_samples = self.generate_map_dataset(map_data)
            all_samples.extend(map_samples)
        
        if not all_samples:
            print("❌ No samples generated!")
            return False
        
        print(f"\n📊 TOTAL SAMPLES GENERATED: {len(all_samples)}")
        
        # Save dataset
        train_count, test_count = self.save_dataset_samples(all_samples, dirs)
        
        # Create visualizations
        self.create_sample_visualizations(all_samples, dirs)
        
        # Final summary
        print(f"\n🎉 DATASET GENERATION COMPLETE!")
        print(f"=" * 50)
        print(f"📁 Dataset location: {self.dataset_dir}")
        print(f"📊 Training samples: {train_count}")
        print(f"📊 Test samples: {test_count}")
        print(f"📊 Total samples: {len(all_samples)}")
        print(f"\n📋 Next steps:")
        print(f"   1. Review visualizations in: {dirs['visualizations']}")
        print(f"   2. Run LAMA training with dataset: {self.dataset_dir}")
        
        return self.dataset_dir

def main():
    """
    MAIN FUNCTION - UPDATE THESE PATHS!
    """
    # ==========================================
    # CONFIGURATION - UPDATE THESE PATHS!
    # ==========================================
    
    MAPEX_ROOT = "/home/nivand/MapEx"  # UPDATE YOUR PATH
    
    # Map IDs from Script 1 (converted maps)
    MAP_IDS = ["gazebo_map1", "gazebo_map2", "gazebo_map3"]
    
    # ==========================================
    # GENERATE DATASET
    # ==========================================
    
    generator = GazeboDatasetGenerator(MAPEX_ROOT)
    
    # Optional: Customize parameters for your setup
    generator.config.update({
        'trajectories_per_map': 25,    # More trajectories = more data
        'poses_per_trajectory': 18,    # More poses = more training samples
        'laser_range_m': 10,           # Adjust for your TurtleBot
        'min_unknown_ratio': 0.1,      # Lower threshold = more samples
    })
    
    # Generate complete dataset
    dataset_path = generator.generate_complete_dataset(MAP_IDS)
    
    if dataset_path:
        print(f"\n✅ SUCCESS! Dataset ready for LAMA training")
        print(f"   Dataset path: {dataset_path}")
        print(f"   Use this path in LAMA training configs")
        return True
    else:
        print(f"\n❌ DATASET GENERATION FAILED")
        return False

if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)