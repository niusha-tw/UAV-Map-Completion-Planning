#!/usr/bin/env python3
import rospy
import numpy as np
import cv2
import torch
import os
import matplotlib.pyplot as plt
from nav_msgs.msg import OccupancyGrid, Odometry
from cv_bridge import CvBridge
import std_msgs.msg  # <-- REQUIRED FOR Header
from lama_pred_utils import load_lama_model, get_lama_transform, convert_obsimg_to_model_input, visualize_prediction

class LaMaOnlinePredictor:
    def __init__(self):
        # --- ROS Setup ---
        rospy.init_node('lama_online_predictor', anonymous=True)
        self.bridge = CvBridge()

        # --- Paths ---
        self.model_path = '/home/nivand/MapEx/pretrained_models/weights/big_lama'
        self.gt_map_path = '/home/nivand/MapEx/scripts/hmap.png'  # <--- your GT PNG

        # --- LaMa Model ---
        self.device = 'cpu'
        self.lama_model = load_lama_model(self.model_path, device=self.device)
        self.lama_transform = get_lama_transform('default_map_eval', (512, 512))

        # --- Buffers ---
        self.latest_map = None
        self.latest_odom = None
        self.trajectory = []

        # --- Subscribers ---
        rospy.Subscriber('/map', OccupancyGrid, self.map_callback)
        rospy.Subscriber('/odom', Odometry, self.odom_callback)

        # --- Load GT ---
        self.gt_map = cv2.imread(self.gt_map_path, cv2.IMREAD_GRAYSCALE)
        if self.gt_map is None:
            rospy.logwarn("Ground-truth map PNG not found!")
            self.gt_map = None

        # --- Visualization ---
        plt.ion()
        self.fig, self.axes = plt.subplots(1, 3, figsize=(18, 6))

        # --- Output ---
        self.save_dir = '/home/nivand/MapEx/TURTLE'
        os.makedirs(self.save_dir, exist_ok=True)
        self.frame_idx = 0
        self.lama_pub = rospy.Publisher('/lama_predicted_map', OccupancyGrid, queue_size=1)

    def publish_lama_map(self, pred_img):
        from nav_msgs.msg import OccupancyGrid
        msg = OccupancyGrid()
        # Use *the same* origin/resolution as your /map
        msg.info.resolution = 0.05
        msg.info.width = 384
        msg.info.height = 384
        msg.info.origin.position.x = -10.0
        msg.info.origin.position.y = -10.0
        msg.info.origin.position.z = 0.0
        msg.info.origin.orientation.x = 0.0
        msg.info.origin.orientation.y = 0.0
        msg.info.origin.orientation.z = 0.0
        msg.info.origin.orientation.w = 1.0
        msg.header.stamp = rospy.Time.now()
        msg.header.frame_id = "map"

        # Resize pred_img if needed
        pred_img_resized = cv2.resize(pred_img, (384, 384), interpolation=cv2.INTER_NEAREST)

        gray_pred = cv2.cvtColor(pred_img_resized, cv2.COLOR_BGR2GRAY)
        map_data = np.full((384, 384), -1, dtype=np.int8)
        map_data[gray_pred < 80] = 100   # Occupied
        map_data[gray_pred > 180] = 0    # Free

        msg.data = map_data.flatten().tolist()
        self.lama_pub.publish(msg)

    def publishlama_map(self, pred_img):
        msg = OccupancyGrid()
        msg.header = std_msgs.msg.Header()
        msg.header.stamp = rospy.Time.now()
        msg.header.frame_id = "map"

        h, w = pred_img.shape[:2]
        msg.info.resolution = 0.05  # <-- set to match your map
        msg.info.width = w
        msg.info.height = h
        msg.info.origin.position.x = 0.0
        msg.info.origin.position.y = 0.0
        msg.info.origin.position.z = 0.0
        msg.info.origin.orientation.w = 1.0

        msg.info.origin.position.x = -10.0
        msg.info.origin.position.y = -10.0
        msg.info.resolution = 0.05


        gray_pred = cv2.cvtColor(pred_img, cv2.COLOR_BGR2GRAY)
        map_data = np.full((h, w), -1, dtype=np.int8)  # unknown

        # --- Set thresholds for map classes ---
        map_data[gray_pred < 80] = 100   # occupied
        map_data[gray_pred > 180] = 0    # free
        # else remains -1

        msg.data = map_data.flatten().tolist()
        self.lama_pub.publish(msg)

    def map_callback(self, msg):
        w, h = msg.info.width, msg.info.height
        data = np.array(msg.data, dtype=np.int16).reshape(h, w)
        obs_map = np.zeros_like(data, dtype=np.float32)
        obs_map[data == 0] = 0       # Free
        obs_map[data == 100] = 1     # Occupied
        obs_map[data == -1] = 0.5    # Unknown
        self.latest_map = obs_map
        self.run_lama_and_visualize()

    def odom_callback(self, msg):
        # Store robot position (x, y), adjust if you want pixel coordinates
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        self.trajectory.append([x, y])

    def run_lama_and_visualize(self):
        if self.latest_map is None:
            return
        obs_map = self.latest_map
        h, w = obs_map.shape

        # -- Prepare color image for LaMa --
        obs_img = np.zeros((h, w, 3), dtype=np.uint8)
        obs_img[obs_map == 0] = [255, 255, 255]
        obs_img[obs_map == 0.5] = [128, 128, 128]
        obs_img[obs_map == 1] = [0, 0, 0]

        # -- LaMa prediction --
        input_batch, mask = convert_obsimg_to_model_input(obs_img, self.lama_transform, self.device)
        with torch.no_grad():
            pred = self.lama_model(input_batch)
        lama_pred_img = visualize_prediction(pred, mask)

        # -- Visualization, Save, and Publish --
        self.visualize(obs_img, lama_pred_img)
        self.publish_lama_map(lama_pred_img)
        save_path = os.path.join(self.save_dir, f'lama_pred_{self.frame_idx:04d}.png')
        cv2.imwrite(save_path, lama_pred_img)
        self.frame_idx += 1

    def visualize(self, obs_img, pred_img):
        ax = self.axes

        # Observed map + trajectory
        ax[0].cla()
        ax[0].imshow(obs_img, cmap='gray')
        if len(self.trajectory) > 0:
            poses = np.array(self.trajectory)
            ax[0].plot(poses[:, 0], poses[:, 1], 'r-', label='Trajectory')
        ax[0].set_title('Observed Map & Trajectory')

        # LaMa prediction
        ax[1].cla()
        ax[1].imshow(pred_img)
        ax[1].set_title('LaMa Predicted Map')

        # GT
        ax[2].cla()
        if self.gt_map is not None:
            gt_resized = cv2.resize(self.gt_map, (obs_img.shape[1], obs_img.shape[0]), interpolation=cv2.INTER_NEAREST)
            ax[2].imshow(gt_resized, cmap='gray')
            ax[2].set_title('Ground Truth')
        else:
            ax[2].text(0.5, 0.5, 'No GT Map', fontsize=18, ha='center')

        plt.tight_layout()
        plt.pause(0.01)

    def spin(self):
        rospy.loginfo('LaMa Online Predictor started!')
        rospy.spin()

if __name__ == '__main__':
    node = LaMaOnlinePredictor()
    node.spin()
