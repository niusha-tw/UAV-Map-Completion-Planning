import numpy as np
import matplotlib.pyplot as plt
import sys
import os
import range_libc
# --- 1. Add range_libc to path if not globally installed ---
# custom imports
import sys
sys.path.append('../')

# --- 2. Load map and valid mask ---
occ_map = np.load('../kth_test_maps/50052750/occ_map.npy')    # adjust path and map as needed
valid_space = np.load('../kth_test_maps/50052750/valid_space.npy')

# --- 3. Parameters ---
start_y, start_x = 515, 515    # Pick a valid free cell as your start
lidar_range = 8                # 8 pixels/meters max range
num_beams = 60                 # Number of lidar rays
show_path = True               # Toggle to show/hide the robot path
NOISE = False                  # Set True for noisy movement

motion_noise_std = 1.5         # 1.5 pixels (adjust as you like)

# --- 4. Prepare range_libc raycaster ---
occ = np.ascontiguousarray(occ_map.astype(np.uint8))
h, w = occ.shape

rc = range_libc.PyOMap(occ)
# --- 5. Setup plot and robot state ---
plt.ion()
robot_pos = [start_y, start_x]
robot_path = [tuple(robot_pos)]
observed_map = np.zeros_like(occ_map)

fig, ax = plt.subplots(figsize=(10,10))

move_dict = {'w':(-1,0), 's':(1,0), 'a':(0,-1), 'd':(0,1)}

def get_visibility_mask(rc, pose, num_beams, max_range):
    y, x = pose
    angles = np.linspace(0, 2*np.pi, num_beams, endpoint=False)
    scan = rc.calc_range_many(x, y, angles, max_range)
    vis = np.zeros_like(occ_map)
    for i, rng in enumerate(scan):
        steps = int(rng)
        for r in range(1, steps+1):
            yy = int(round(y + r * np.sin(angles[i])))
            xx = int(round(x + r * np.cos(angles[i])))
            if 0 <= yy < occ_map.shape[0] and 0 <= xx < occ_map.shape[1]:
                vis[yy, xx] = 1
    return vis

print("\nInteractive exploration started!")
print("Use keys: w=up, s=down, a=left, d=right, q=quit")
if NOISE:
    print("Motion noise is ON.\n")
else:
    print("Motion noise is OFF.\n")

while True:
    # 1. Lidar
    vis_mask = get_visibility_mask(rc, robot_pos, num_beams=num_beams, max_range=lidar_range)
    observed_map = np.maximum(observed_map, vis_mask)
    robot_path_np = np.array(robot_path)

    # 2. Plot
    ax.clear()
    ax.imshow(occ_map, cmap='gray', alpha=1.0)
    ax.imshow(np.ma.masked_where(observed_map == 0, observed_map), cmap='Blues', alpha=0.55)
    ax.imshow(np.ma.masked_where(vis_mask == 0, vis_mask), cmap='YlOrBr', alpha=0.4)
    if show_path and len(robot_path_np) > 1:
        ax.plot(robot_path_np[:,1], robot_path_np[:,0], 'r-', linewidth=2, label='Path')
    ax.plot(robot_pos[1], robot_pos[0], 'ro', markersize=12, label='Robot')
    ax.legend()
    ax.set_title("MapEx-style Keyboard Teleop\nw/a/s/d=move, q=quit, noise={}".format(NOISE))
    ax.axis('off')
    plt.draw()
    plt.pause(0.01)

    # 3. Keyboard input
    key = input("Move (w/a/s/d/q): ").strip().lower()
    if key == 'q':
        print("Exiting interactive session.")
        break
    if key not in move_dict:
        print("Invalid key. Use w/a/s/d/q.")
        continue

    dy, dx = move_dict[key]
    ny, nx = robot_pos[0]+dy, robot_pos[1]+dx

    # Optionally, add Gaussian noise to motion
    if NOISE:
        ny = int(round(ny + np.random.normal(0, motion_noise_std)))
        nx = int(round(nx + np.random.normal(0, motion_noise_std)))

    # Bounds and validity check
    if (0 <= ny < occ_map.shape[0] and 0 <= nx < occ_map.shape[1] and
        valid_space[ny, nx] and occ_map[ny, nx]==0):
        robot_pos = [ny, nx]
        robot_path.append(tuple(robot_pos))
    else:
        print("Blocked or out of bounds.")

plt.ioff()
plt.show()
