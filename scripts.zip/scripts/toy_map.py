import matplotlib.pyplot as plt
import numpy as np
import random

# 1. Load map and binarize
img = plt.imread('gt_map.png')
if img.ndim == 3:
    img = img[:,:,0]
occupancy = (img > 0.5).astype(int)

# 2. Parameters and Start
start_y, start_x = 80, 120  # adjust as needed!
robot_path = [(start_y, start_x)]
observed_map = np.zeros_like(occupancy)

# 3. Lidar Simulation
def simulate_lidar(map, pose, max_range=60, num_rays=64):
    obs = np.zeros_like(map)
    angles = np.linspace(0, 2*np.pi, num_rays, endpoint=False)
    y0, x0 = pose
    for ang in angles:
        for r in range(1, max_range+1):
            y = int(round(y0 + r * np.sin(ang)))
            x = int(round(x0 + r * np.cos(ang)))
            if 0 <= y < map.shape[0] and 0 <= x < map.shape[1]:
                obs[y, x] = 1
                if map[y, x] == 1:
                    break
            else:
                break
    return obs

# 4. Fake LaMa Inpainting (as before)
def fake_lama_inpaint(obs_map):
    pred_map = obs_map.copy().astype(float)
    uncertainty = 0.2 + 0.8 * (1 - obs_map)
    return pred_map, uncertainty

# 5. Random Walk Parameters
num_steps = 150
step_size = 8  # move up to 8 pixels in x/y each step

curr_y, curr_x = start_y, start_x

for i in range(num_steps):
    # Simulate Lidar at current position
    obs = simulate_lidar(occupancy, (curr_y, curr_x))
    observed_map = np.maximum(observed_map, obs)
    robot_path.append((curr_y, curr_x))
    
    # Generate possible moves: up, down, left, right, diagonal (with random step size)
    moves = [
        (curr_y - step_size, curr_x),     # up
        (curr_y + step_size, curr_x),     # down
        (curr_y, curr_x - step_size),     # left
        (curr_y, curr_x + step_size),     # right
        (curr_y - step_size, curr_x - step_size),   # up-left
        (curr_y - step_size, curr_x + step_size),   # up-right
        (curr_y + step_size, curr_x - step_size),   # down-left
        (curr_y + step_size, curr_x + step_size),   # down-right
    ]
    # Shuffle for random walk
    random.shuffle(moves)
    found = False
    for ny, nx in moves:
        ny, nx = int(ny), int(nx)
        # Check if in bounds and not inside wall
        if (0 <= ny < occupancy.shape[0] and 0 <= nx < occupancy.shape[1] 
            and occupancy[ny, nx] == 0):
            curr_y, curr_x = ny, nx
            found = True
            break
    if not found:
        # If stuck, pick a random free cell in the map as a teleport
        free_cells = np.argwhere(occupancy == 0)
        idx = np.random.choice(len(free_cells))
        curr_y, curr_x = free_cells[idx]

# Final scan at last pose
obs = simulate_lidar(occupancy, (curr_y, curr_x))
observed_map = np.maximum(observed_map, obs)
robot_path.append((curr_y, curr_x))

# 6. Fake Prediction
pred_map, uncertainty_map = fake_lama_inpaint(observed_map)

# 7. Visualization in MapEx style
fig, axs = plt.subplots(2, 2, figsize=(12, 12))

# Observed image with path
axs[0,0].imshow(0.5*np.ones_like(occupancy), cmap='gray')  # gray background
axs[0,0].imshow(observed_map, cmap='gray', alpha=0.8)
robot_path_np = np.array(robot_path)
axs[0,0].plot(robot_path_np[:,1], robot_path_np[:,0], 'r-', linewidth=2)
axs[0,0].set_title("Observed Image (red=path)")

# Ground truth
axs[0,1].imshow(occupancy, cmap='gray')
axs[0,1].set_title("Ground Truth")

# Prediction
axs[1,0].imshow(pred_map, cmap='gray')
axs[1,0].plot(robot_path_np[:,1], robot_path_np[:,0], 'r-', linewidth=2)
axs[1,0].set_title("All Train Prediction (Fake)")

# Uncertainty (optional)
axs[1,1].imshow(uncertainty_map, cmap='hot')
axs[1,1].set_title("Uncertainty Map (Fake)")

for ax in axs.flat:
    ax.axis('off')
plt.tight_layout()
plt.show()
