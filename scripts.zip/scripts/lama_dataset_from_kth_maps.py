#!/usr/bin/env python3
import os, cv2, numpy as np, math, random
from tqdm import tqdm

# === USER PATHS ===
KTH_DIR = "/home/nivand/MapEx/kth_test_maps"
OUT_DIR = "/home/nivand/MapEx/lamacustom_dataset"

PIXELS_PER_METER = 50
MAP_RES = 1.0 / PIXELS_PER_METER
LIDAR_RANGE = 3.5
NUM_LASER = 359
NUM_SAMPLES = 5

PARTIAL_DIR = os.path.join(OUT_DIR, "train/global_map")
MASK_DIR = os.path.join(OUT_DIR, "train/global_mask")
os.makedirs(PARTIAL_DIR, exist_ok=True)
os.makedirs(MASK_DIR, exist_ok=True)

def raycast_2d(occ, pose, angles, rmax, res):
    hits = []
    h, w = occ.shape
    ox, oy, theta = pose
    for a in angles:
        for r in np.linspace(0, rmax, int(rmax/res)):
            x = int(ox + (r/res)*math.cos(theta + a))
            y = int(oy + (r/res)*math.sin(theta + a))
            if not (0<=x<w and 0<=y<h): break
            hits.append((x,y))
            if occ[y,x]: break
    return hits

map_dirs = [d for d in os.listdir(KTH_DIR) if d.startswith("gazebo_map")]
for m in tqdm(map_dirs, desc="Maps"):
    occ = np.load(os.path.join(KTH_DIR, m, "occ_map.npy"))
    occ_bin = (occ == 0).astype(np.uint8)
    target = np.stack([occ]*3, axis=2).astype(np.uint8)
    target[occ == 254] = 255
    target[occ == 0] = 0
    target[(occ != 0) & (occ != 254)] = 127
    free = np.argwhere(occ == 254)
    if free.size == 0: continue
    angles = np.linspace(-math.pi, math.pi, NUM_LASER, endpoint=False)
    for i in range(NUM_SAMPLES):
        y, x = random.choice(free)
        hits = raycast_2d(occ_bin, (x,y, random.uniform(-math.pi,math.pi)), angles, LIDAR_RANGE, MAP_RES)
        mask = np.zeros_like(occ, dtype=np.uint8)
        for xx,yy in hits:
            if 0<=yy<occ.shape[0]: mask[yy,xx]=255
        partial = target.copy()
        for c in range(3):
            partial[:,:,c][mask==0] = 127
        fn = f"{m}_obs_{i}.png"
        cv2.imwrite(os.path.join(PARTIAL_DIR, fn), partial)
        cv2.imwrite(os.path.join(MASK_DIR, fn), mask)
print("Dataset ready!")
