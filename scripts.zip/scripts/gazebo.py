# LAMA-based TurtleBot Gazebo Integration with Lightweight PyTorch Model (No Config YAML)

import os
import cv2
import numpy as np
import torch
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from torchvision import transforms

import rospy
from nav_msgs.msg import OccupancyGrid, Odometry
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from collections import deque

from saicinpainting.evaluation.refinement import load_predictor

class TurtleBotLightLAMA:
    def __init__(self):
        rospy.init_node('turtlebot_light_lama')

        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.model_path = '/home/nivand/MapEx/pretrained_models/big_lama_CKPT.pth'  # .pth checkpoint
        self.model, self.transform = self.load_lama_model()

        self.map_size = (1000, 1000)
        self.resolution = 0.05
        self.origin = np.array([500, 500])
        self.obs_map = np.ones(self.map_size) * 0.5
        self.robot_pose = self.origin.copy()
        self.pose_history = deque(maxlen=1000)

        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)
        self.laser_sub = rospy.Subscriber('/scan', LaserScan, self.laser_callback)
        self.cmd_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.lama_pub = rospy.Publisher('/lama_map_predicted', OccupancyGrid, queue_size=1)

        self.exploration_step = 0

        plt.ion()
        self.fig, self.axs = plt.subplots(1, 2, figsize=(10, 5))
        self.last_pred_img = None

    def load_lama_model(self):
        predictor = load_predictor(self.model_path, device=self.device)
        model = predictor.model
        model.eval()
        transform = transforms.Compose([
            transforms.ToTensor(),
            lambda x: x * 2 - 1
        ])
        return model, transform

    def odom_callback(self, msg):
        x = msg.pose.pose.position.x / self.resolution + self.origin[0]
        y = msg.pose.pose.position.y / self.resolution + self.origin[1]
        self.robot_pose = np.array([int(y), int(x)])
        self.pose_history.append(self.robot_pose.copy())

    def laser_callback(self, msg):
        if len(msg.ranges) == 0:
            return
        self.update_occupancy_grid(msg)
        if self.exploration_step % 10 == 0:
            self.run_lama_prediction()
            self.publish_pred_map()
        self.exploration_step += 1

    def update_occupancy_grid(self, laser_msg):
        ranges = np.array(laser_msg.ranges)
        angles = np.linspace(laser_msg.angle_min, laser_msg.angle_max, len(ranges))
        valid = (ranges > laser_msg.range_min) & (ranges < laser_msg.range_max)
        robot_row, robot_col = self.robot_pose
        for r, a in zip(ranges[valid], angles[valid]):
            end_x = robot_col + (r / self.resolution) * np.cos(a)
            end_y = robot_row + (r / self.resolution) * np.sin(a)
            end_row, end_col = int(end_y), int(end_x)
            if 0 <= end_row < self.map_size[0] and 0 <= end_col < self.map_size[1]:
                ray = self.bresenham_line(robot_row, robot_col, end_row, end_col)
                for y, x in ray[:-1]:
                    self.obs_map[y, x] = 0
                self.obs_map[end_row, end_col] = 1

    def bresenham_line(self, x0, y0, x1, y1):
        points = []
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        x, y = x0, y0
        sx = -1 if x0 > x1 else 1
        sy = -1 if y0 > y1 else 1
        if dx > dy:
            err = dx / 2.0
            while x != x1:
                points.append((x, y))
                err -= dy
                if err < 0:
                    y += sy
                    err += dx
                x += sx
        else:
            err = dy / 2.0
            while y != y1:
                points.append((x, y))
                err -= dx
                if err < 0:
                    x += sx
                    err += dy
                y += sy
        points.append((x1, y1))
        return points

    def prepare_input_image(self):
        h, w = self.obs_map.shape
        img = np.zeros((h, w, 3), np.uint8)
        img[self.obs_map == 0.5] = 128
        img[self.obs_map == 1.0] = 0
        return img

    def run_lama_prediction(self):
        img = self.prepare_input_image()
        t = self.transform(img).unsqueeze(0).to(self.device)
        mask = (img[..., 0] == 128).astype(np.uint8)
        m = torch.from_numpy(mask)[None, None].to(self.device)
        with torch.no_grad():
            pred = self.model(t, m)
        out = ((pred[0].cpu().permute(1, 2, 0).numpy() + 1) / 2 * 255).astype(np.uint8)
        self.last_pred_img = out

    def publish_pred_map(self):
        if self.last_pred_img is None:
            return
        gray = cv2.cvtColor(self.last_pred_img, cv2.COLOR_BGR2GRAY)
        grid = np.full(gray.shape, -1, dtype=np.int8)
        grid[gray < 100] = 100
        grid[gray > 200] = 0
        msg = OccupancyGrid()
        msg.header.stamp = rospy.Time.now()
        msg.header.frame_id = 'map'
        msg.info.resolution = self.resolution
        msg.info.width = grid.shape[1]
        msg.info.height = grid.shape[0]
        msg.info.origin.position.x = -self.origin[0] * self.resolution
        msg.info.origin.position.y = -self.origin[1] * self.resolution
        msg.info.origin.orientation.w = 1.0
        msg.data = grid.flatten().tolist()
        self.lama_pub.publish(msg)

    def visualize(self):
        self.axs[0].cla()
        self.axs[1].cla()
        self.axs[0].imshow(self.obs_map, cmap='gray')
        self.axs[0].scatter(self.robot_pose[1], self.robot_pose[0], c='red')
        if self.last_pred_img is not None:
            self.axs[1].imshow(self.last_pred_img)
        self.axs[0].set_title("Observed")
        self.axs[1].set_title("LAMA Prediction")
        plt.pause(0.01)

    def run(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            self.visualize()
            rate.sleep()

if __name__ == '__main__':
    try:
        explorer = TurtleBotLightLAMA()
        explorer.run()
    except rospy.ROSInterruptException:
        pass
