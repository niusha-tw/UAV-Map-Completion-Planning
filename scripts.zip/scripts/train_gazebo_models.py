#!/usr/bin/env python3
"""
STREAMLINED LAMA TRAINING FOR GAZEBO MAPS
This script does everything: dataset generation + training in one go
"""

import os
import cv2
import numpy as np
import shutil
import subprocess
import yaml
from pathlib import Path
import matplotlib.pyplot as plt
from tqdm import tqdm

class GazeboLAMATrainer:
    def __init__(self, mapex_root, gazebo_pgm_paths):
        """
        mapex_root: Path to your MapEx installation
        gazebo_pgm_paths: List of paths to your 3 Gazebo PGM files
        """
        self.mapex_root = Path(mapex_root)
        self.gazebo_pgm_paths = gazebo_pgm_paths
        self.lama_dir = self.mapex_root / "lama"
        self.maps_dir = self.mapex_root / "kth_test_maps"
        self.dataset_dir = self.mapex_root / "gazebo_dataset"
        self.models_dir = self.mapex_root / "pretrained_models" / "gazebo_weights"
        
        # TurtleBot parameters
        self.turtlebot_config = {
            'laser_range_m': 8,          # TurtleBot typical range
            'num_laser': 360,            # 360 degree coverage
            'pixel_per_meter': 20,       # High resolution for indoor
            'trajectories_per_map': 25,   # Training trajectories
            'poses_per_trajectory': 12,   # Observation points
        }
        
        print(f"🏠 MapEx root: {self.mapex_root}")
        print(f"🤖 TurtleBot laser range: {self.turtlebot_config['laser_range_m']}m")
        print(f"📡 Number of laser rays: {self.turtlebot_config['num_laser']}")
    
    def step1_convert_maps(self):
        """Convert PGM files to MapEx format"""
        print("\n🗺️  STEP 1: Converting Gazebo maps to MapEx format")
        print("=" * 50)
        
        for i, pgm_path in enumerate(self.gazebo_pgm_paths, 1):
            map_id = f"gazebo_map{i}"
            print(f"\nProcessing {map_id}: {pgm_path}")
            
            if not Path(pgm_path).exists():
                print(f"❌ File not found: {pgm_path}")
                continue
            
            # Create map directory
            map_dir = self.maps_dir / map_id
            map_dir.mkdir(parents=True, exist_ok=True)
            
            # Load PGM
            pgm_img = cv2.imread(pgm_path, cv2.IMREAD_GRAYSCALE)
            if pgm_img is None:
                print(f"❌ Could not load: {pgm_path}")
                continue
            
            print(f"   📏 Original size: {pgm_img.shape}")
            print(f"   🎨 Original values: {np.unique(pgm_img)}")
            
            # Convert to MapEx format: EXACTLY [0, 254]
            occ_map = np.zeros_like(pgm_img, dtype=np.uint8)
            occ_map[pgm_img == 0] = 0      # black -> occupied (0)
            occ_map[pgm_img > 0] = 254     # white -> free (254)
            
            # Create valid space
            valid_space = np.zeros_like(pgm_img, dtype=np.uint8)
            valid_space[pgm_img > 0] = 255  # free areas are navigable
            
            # Save files
            np.save(map_dir / "occ_map.npy", occ_map)
            np.save(map_dir / "valid_space.npy", valid_space)
            cv2.imwrite(str(map_dir / "map.png"), pgm_img)
            
            # Verify
            occ_unique = np.unique(occ_map)
            if not np.array_equal(occ_unique, [0, 254]):
                print(f"❌ Wrong format: {occ_unique}")
                return False
            
            print(f"   ✅ Converted successfully!")
            print(f"   📁 Saved to: {map_dir}")
        
        return True
    
    def step2_generate_dataset(self):
        """Generate training dataset using simple raycasting"""
        print("\n📊 STEP 2: Generating training dataset")
        print("=" * 50)
        
        # Create dataset directories
        train_dir = self.dataset_dir / "train"
        test_dir = self.dataset_dir / "test"
        train_dir.mkdir(parents=True, exist_ok=True)
        test_dir.mkdir(parents=True, exist_ok=True)
        
        all_samples = []
        
        # Process each map
        for i in range(1, 4):  # gazebo_map1, gazebo_map2, gazebo_map3
            map_id = f"gazebo_map{i}"
            map_dir = self.maps_dir / map_id
            
            if not (map_dir / "occ_map.npy").exists():
                print(f"⚠️  Skipping {map_id} - not found")
                continue
            
            print(f"\n🗺️  Processing {map_id}...")
            
            # Load map
            occ_map = np.load(map_dir / "occ_map.npy")
            valid_space = np.load(map_dir / "valid_space.npy")
            
            # Convert to internal format (0=unknown, 1=occupied, 2=free)
            internal_map = np.zeros_like(occ_map)
            internal_map[occ_map == 0] = 1    # occupied
            internal_map[occ_map == 254] = 2  # free
            
            # Generate samples for this map
            map_samples = self._generate_map_samples(internal_map, valid_space, map_id)
            all_samples.extend(map_samples)
            
            print(f"   ✅ Generated {len(map_samples)} samples")
        
        if not all_samples:
            print("❌ No samples generated!")
            return False
        
        # Split train/test (80/20)
        np.random.shuffle(all_samples)
        split_idx = int(len(all_samples) * 0.8)
        train_samples = all_samples[:split_idx]
        test_samples = all_samples[split_idx:]
        
        print(f"\n💾 Saving dataset...")
        print(f"   Training samples: {len(train_samples)}")
        print(f"   Test samples: {len(test_samples)}")
        
        # Save samples
        self._save_samples(train_samples, train_dir)
        self._save_samples(test_samples, test_dir)
        
        print(f"✅ Dataset saved to: {self.dataset_dir}")
        return True
    
    def _generate_map_samples(self, occupancy_map, valid_space, map_id):
        """Generate training samples from one map"""
        samples = []
        
        # Find valid robot positions
        valid_positions = np.where(valid_space > 0)
        if len(valid_positions[0]) < 50:
            print(f"   ⚠️  Warning: Only {len(valid_positions[0])} valid positions")
            return samples
        
        print(f"   🎯 Generating {self.turtlebot_config['trajectories_per_map']} trajectories...")
        
        for traj_i in tqdm(range(self.turtlebot_config['trajectories_per_map']), desc="Trajectories"):
            # Random start position
            start_idx = np.random.randint(len(valid_positions[0]))
            start_pos = (valid_positions[0][start_idx], valid_positions[1][start_idx])
            
            # Random end position
            end_idx = np.random.randint(len(valid_positions[0]))
            end_pos = (valid_positions[0][end_idx], valid_positions[1][end_idx])
            
            # Check minimum distance
            distance = np.linalg.norm(np.array(start_pos) - np.array(end_pos))
            if distance < 100:  # Skip too short trajectories
                continue
            
            # Create trajectory
            trajectory = self._create_trajectory(start_pos, end_pos)
            
            # Generate observations along trajectory
            cumulative_observed = np.ones_like(occupancy_map) * 0.5  # Start unknown
            
            for pose_i, pose in enumerate(trajectory):
                # Simulate TurtleBot observation
                new_observation = self._simulate_turtlebot_lidar(pose, occupancy_map)
                
                # Update cumulative map
                cumulative_observed[new_observation != 0.5] = new_observation[new_observation != 0.5]
                
                # Create training sample
                sample = self._create_lama_sample(cumulative_observed, map_id, traj_i, pose_i)
                if sample is not None:
                    samples.append(sample)
        
        return samples
    
    def _simulate_turtlebot_lidar(self, robot_pos, occupancy_map):
        """Simple circular raycast simulation for TurtleBot"""
        observed = np.ones_like(occupancy_map) * 0.5  # Start with unknown
        
        # TurtleBot specs
        max_range_pixels = int(self.turtlebot_config['laser_range_m'] * self.turtlebot_config['pixel_per_meter'])
        num_rays = self.turtlebot_config['num_laser']
        
        # Cast rays in all directions
        angles = np.linspace(0, 2*np.pi, num_rays)
        
        for angle in angles:
            # Cast ray from robot position
            for r in range(1, max_range_pixels):
                x = int(robot_pos[0] + r * np.cos(angle))
                y = int(robot_pos[1] + r * np.sin(angle))
                
                # Check bounds
                if (x < 0 or x >= occupancy_map.shape[0] or 
                    y < 0 or y >= occupancy_map.shape[1]):
                    break
                
                # Mark as observed
                observed[x, y] = occupancy_map[x, y]
                
                # Stop if hit obstacle
                if occupancy_map[x, y] == 1:  # occupied
                    break
        
        return observed
    
    def _create_trajectory(self, start, end):
        """Create simple linear trajectory"""
        num_poses = self.turtlebot_config['poses_per_trajectory']
        trajectory = []
        
        for i in range(num_poses):
            t = i / (num_poses - 1)
            pose = (
                int(start[0] + t * (end[0] - start[0])),
                int(start[1] + t * (end[1] - start[1]))
            )
            trajectory.append(pose)
        
        return trajectory
    
    def _create_lama_sample(self, observed_map, map_id, traj_id, pose_id):
        """Convert observation to LAMA training format"""
        # Check if we have enough unknown regions to make it interesting
        unknown_ratio = np.sum(observed_map == 0.5) / observed_map.size
        if unknown_ratio < 0.1:  # Skip if less than 10% unknown
            return None
        
        # Create RGB image
        image = np.zeros((*observed_map.shape, 3), dtype=np.uint8)
        image[observed_map == 0.5] = [128, 128, 128]  # unknown -> gray
        image[observed_map == 2] = [255, 255, 255]    # free -> white  
        image[observed_map == 1] = [0, 0, 0]          # occupied -> black
        
        # Create inpainting mask
        mask = np.zeros(observed_map.shape, dtype=np.uint8)
        mask[observed_map == 0.5] = 255  # unknown regions to inpaint
        
        # Resize to LAMA input size
        image_512 = cv2.resize(image, (512, 512))
        mask_512 = cv2.resize(mask, (512, 512))
        
        return {
            'image': image_512,
            'mask': mask_512,
            'id': f"{map_id}_t{traj_id:03d}_p{pose_id:03d}"
        }
    
    def _save_samples(self, samples, output_dir):
        """Save samples in LAMA format"""
        for i, sample in enumerate(tqdm(samples, desc="Saving")):
            filename = f"{sample['id']}_{i:06d}.png"
            
            cv2.imwrite(str(output_dir / filename), sample['image'])
            cv2.imwrite(str(output_dir / f"mask_{filename}"), sample['mask'])
    
    def step3_train_models(self):
        """Train LAMA models"""
        print("\n🎯 STEP 3: Training LAMA models")
        print("=" * 50)
        
        # Navigate to LAMA directory
        os.chdir(self.lama_dir)
        
        # Create training config
        config = self._create_training_config()
        
        # Train main model
        print("\n🚀 Training main model...")
        self._run_training("gazebo_main", config, epochs=80)
        
        # Train ensemble models
        for i in range(1, 4):
            print(f"\n🚀 Training ensemble model {i}...")
            ensemble_config = config.copy()
            ensemble_config['location'] = f'gazebo_ensemble_{i}'
            ensemble_config['training']['num_epochs'] = 60
            self._run_training(f"gazebo_ensemble_{i}", ensemble_config, epochs=60)
        
        return True
    
    def _create_training_config(self):
        """Create LAMA training configuration"""
        return {
            'model': {
                'kind': 'default',
                'generator': {
                    'kind': 'ffc_resnet',
                    'input_nc': 4,
                    'output_nc': 3,
                    'ngf': 64,
                    'n_downsampling': 3,
                    'n_blocks': 18,
                    'add_out_act': 'sigmoid',
                    'max_features': 1024,
                }
            },
            'data': {
                'train': {
                    'indir': str(self.dataset_dir / 'train'),
                    'out_size': 512,
                },
                'validation': {
                    'indir': str(self.dataset_dir / 'test'),
                    'out_size': 512,
                },
                'batch_size': 4,  # Conservative for most GPUs
                'val_batch_size': 2,
                'num_workers': 2,
            },
            'training': {
                'num_epochs': 80,
                'batches_per_epoch': 300,
                'log_interval': 25,
                'checkpoint_interval': 10,
                'val_interval': 5,
                'optimizers': {
                    'generator': {
                        'kind': 'adamw',
                        'lr': 0.001,
                    }
                }
            },
            'losses': {
                'adversarial_weight': 10,
                'segm_weight': 30,
                'perceptual_weight': 30,
                'feature_matching_weight': 100,
                'resnet_pl_weight': 30,
            },
            'location': 'gazebo_main',
        }
    
    def _run_training(self, model_name, config, epochs):
        """Run LAMA training"""
        # Save config
        config_path = self.lama_dir / f"configs/{model_name}.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
        
        # Run training
        cmd = ["python", "bin/train.py", "-cn", model_name]
        
        try:
            result = subprocess.run(cmd, cwd=self.lama_dir, capture_output=True, text=True)
            if result.returncode != 0:
                print(f"❌ Training failed for {model_name}")
                print(f"Error: {result.stderr}")
                return False
            print(f"✅ Training completed for {model_name}")
            return True
        except Exception as e:
            print(f"❌ Training error for {model_name}: {e}")
            return False
    
    def step4_organize_models(self):
        """Move trained models to correct directory structure"""
        print("\n📁 STEP 4: Organizing trained models")
        print("=" * 50)
        
        # Create target directories
        main_dir = self.models_dir / "big_lama" / "models"
        main_dir.mkdir(parents=True, exist_ok=True)
        
        for i in range(1, 4):
            ensemble_dir = self.models_dir / "lama_ensemble" / f"train_{i}" / "models"
            ensemble_dir.mkdir(parents=True, exist_ok=True)
        
        # Move main model
        src_main = self.lama_dir / "experiments" / "gazebo_main" / "models" / "best.ckpt"
        if src_main.exists():
            shutil.copy2(src_main, main_dir / "best.ckpt")
            shutil.copy2(self.lama_dir / "experiments" / "gazebo_main" / "config.yaml", 
                        self.models_dir / "big_lama" / "config.yaml")
            print("✅ Main model organized")
        else:
            print("❌ Main model not found")
        
        # Move ensemble models
        for i in range(1, 4):
            src_ensemble = self.lama_dir / "experiments" / f"gazebo_ensemble_{i}" / "models" / "best.ckpt"
            if src_ensemble.exists():
                dst_dir = self.models_dir / "lama_ensemble" / f"train_{i}"
                shutil.copy2(src_ensemble, dst_dir / "models" / "best.ckpt")
                shutil.copy2(self.lama_dir / "experiments" / f"gazebo_ensemble_{i}" / "config.yaml",
                           dst_dir / "config.yaml")
                print(f"✅ Ensemble model {i} organized")
            else:
                print(f"❌ Ensemble model {i} not found")
        
        print(f"\n📍 Models organized in: {self.models_dir}")
        return True
    
    def step5_create_config(self):
        """Create MapEx configuration for your trained models"""
        print("\n⚙️  STEP 5: Creating MapEx configuration")
        print("=" * 50)
        
        config = {
            'root_path': str(self.mapex_root),
            'collect_world_list': ['gazebo_map1', 'gazebo_map2', 'gazebo_map3'],
            'modes_to_test': ['visvarprob'],
            'start_pose': [400, 400],  # Adjust as needed
            
            # TurtleBot LiDAR configuration
            'lidar_sim_configs': {
                'laser_range_m': self.turtlebot_config['laser_range_m'],
                'num_laser': self.turtlebot_config['num_laser'],
                'pixel_per_meter': self.turtlebot_config['pixel_per_meter'],
                'dilate_diam_for_planning': 2,
            },
            'pred_vis_configs': {
                'laser_range_m': self.turtlebot_config['laser_range_m'],
                'pixel_per_meter': self.turtlebot_config['pixel_per_meter'],
                'num_laser': 180,  # Reduced for faster prediction
            },
            
            # Your trained models
            'ensemble_folder_name': 'gazebo_weights/lama_ensemble',
            'big_lama_model_folder_name': 'gazebo_weights/big_lama',
            'lama_transform_variant': 'default_map_eval',
            'lama_device': 'cuda:0',
            'lama_out_size': [512, 512],
            
            'unknown_as_occ': True,
            'use_distance_transform_for_planning': True,
            'mission_time': 600,  # 10 minutes
        }
        
        config_path = self.mapex_root / "configs" / "gazebo_trained.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
        
        print(f"✅ Configuration saved: {config_path}")
        return config_path
    
    def run_complete_pipeline(self):
        """Run the complete training pipeline"""
        print("🚀 COMPLETE GAZEBO LAMA TRAINING PIPELINE")
        print("=" * 60)
        
        steps = [
            ("Convert Maps", self.step1_convert_maps),
            ("Generate Dataset", self.step2_generate_dataset),
            ("Train Models", self.step3_train_models),
            ("Organize Models", self.step4_organize_models),
            ("Create Config", self.step5_create_config),
        ]
        
        for step_name, step_func in steps:
            print(f"\n🎯 {step_name.upper()}")
            if not step_func():
                print(f"❌ {step_name} failed! Stopping pipeline.")
                return False
        
        print("\n🎉 TRAINING PIPELINE COMPLETE!")
        print("=" * 60)
        print(f"📁 Trained models: {self.models_dir}")
        print(f"⚙️  Config file: {self.mapex_root}/configs/gazebo_trained.yaml")
        print("\n🚀 Test your models:")
        print("cd ~/MapEx/scripts")
        print("python3 explore.py -cn gazebo_trained")
        
        return True

def main():
    """
    MAIN FUNCTION - UPDATE THESE PATHS!
    """
    # ==========================================
    # CONFIGURATION - UPDATE THESE!
    # ==========================================
    
    MAPEX_ROOT = "/home/nivand/MapEx"  # UPDATE THIS
    
    # Your 3 Gazebo PGM files - UPDATE THESE PATHS!
    GAZEBO_PGM_PATHS = [
        "/home/nivand/MapEx/gazebomaps/gazebo_world_1.pgm",  # UPDATE
        "/home/nivand/MapEx/gazebomaps/gazebo_world_2.pgm",  # UPDATE  
        "/home/nivand/MapEx/gazebomaps/gazebo_world_3.pgm",  # UPDATE
        "/home/nivand/MapEx/gazebomaps/gazebo_world_4.pgm",  # UPDATE
        "/home/nivand/MapEx/gazebomaps/gazebo_world_5.pgm",  # UPDATE
    ]
    
    # ==========================================
    # RUN TRAINING PIPELINE
    # ==========================================
    
    trainer = GazeboLAMATrainer(MAPEX_ROOT, GAZEBO_PGM_PATHS)
    success = trainer.run_complete_pipeline()
    
    if success:
        print("\n✅ SUCCESS! Your models are ready for exploration.")
    else:
        print("\n❌ FAILED! Check the error messages above.")
    
    return success

if __name__ == "__main__":
    main()