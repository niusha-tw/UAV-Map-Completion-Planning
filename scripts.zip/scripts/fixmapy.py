import cv2
import numpy as np
import os

def convert_pgm_to_mapex_format(pgm_path, output_dir, map_id):
    # Create map directory
    map_dir = os.path.join(output_dir, map_id)
    os.makedirs(map_dir, exist_ok=True)
    
    # Load PGM
    pgm_img = cv2.imread(pgm_path, cv2.IMREAD_GRAYSCALE)
    
    # Convert to MAPEX format (0: unknown, 1: occupied, 2: free)
    occ_map = np.zeros_like(pgm_img)
    occ_map[pgm_img == 0] = 1      # occupied (black pixels)
    occ_map[pgm_img > 0] = 2       # free (white/gray pixels)
    
    # Create valid space (assume all free space is navigable)
    valid_space = np.zeros_like(pgm_img)
    valid_space[pgm_img > 0] = 1   # navigable areas
    
    # Save as NPY files
    np.save(os.path.join(map_dir, 'occ_map.npy'), occ_map)
    np.save(os.path.join(map_dir, 'valid_space.npy'), valid_space)
    cv2.imwrite(os.path.join(map_dir, 'map.png'), pgm_img)
    
    
    print(f"Converted {pgm_path} to MAPEX format in {map_dir}")

# Convert your 3 Gazebo maps
convert_pgm_to_mapex_format('/home/nivand/MapEx/gazebomaps/gazebo_world_1.pgm', '/home/nivand/MapEx/kth_test_maps', 'gazebo_map1')
convert_pgm_to_mapex_format('/home/nivand/MapEx/gazebomaps/gazebo_world_2.pgm', '/home/nivand/MapEx/kth_test_maps', 'gazebo_map2') 
convert_pgm_to_mapex_format('/home/nivand/MapEx/gazebomaps/gazebo_world_3.pgm', '/home/nivand/MapEx/kth_test_maps', 'gazebo_map3')
convert_pgm_to_mapex_format('/home/nivand/MapEx/gazebomaps/gazebo_world_4.pgm', '/home/nivand/MapEx/kth_test_maps', 'gazebo_map4')
convert_pgm_to_mapex_format('/home/nivand/MapEx/gazebomaps/gazebo_world_5.pgm', '/home/nivand/MapEx/kth_test_maps', 'gazebo_map5')